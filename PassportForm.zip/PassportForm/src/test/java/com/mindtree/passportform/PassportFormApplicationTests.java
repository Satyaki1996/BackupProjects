package com.mindtree.passportform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassportFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
