package com.mindtree.passportform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassportFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassportFormApplication.class, args);
	}

}
