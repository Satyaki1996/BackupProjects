package com.mindtree.passportform.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Passport {
	@Id
	@Column(name = "PASSPORT_NUMBER")
	private int passportNo;

	@Column(name = "COUNTRY_OF_ISSUE")
	private String issueCountry;

	public Passport() {
		super();

	}

	public Passport(int passportNo, String issueCountry) {
		super();
		this.passportNo = passportNo;
		this.issueCountry = issueCountry;
	}

	public int getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(int passportNo) {
		this.passportNo = passportNo;
	}

	public String getIssueCountry() {
		return issueCountry;
	}

	public void setIssueCountry(String issueCountry) {
		this.issueCountry = issueCountry;
	}

}
