package com.mindtree.passportform.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.passportform.entity.Person;

@Service
public interface PassportService {

	public Person insertPassportDetailsIntoDb(Person person);

	public List<Person> getAllDetailsFromDb(int passportNo);

}
