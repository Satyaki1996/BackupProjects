package com.mindtree.passportform.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.passportform.entity.Person;
import com.mindtree.passportform.repository.PersonRepository;
import com.mindtree.passportform.service.PassportService;

@Service
public class PassportServiceImpl implements PassportService {
	
	@Autowired
	PersonRepository personRepository;

	@Override
	public Person insertPassportDetailsIntoDb(Person person) {
		
		return personRepository.saveAndFlush(person);
		
	}

	@Override
	public List<Person> getAllDetailsFromDb(int passportNo) {
		List<Person> result = new ArrayList<Person>();
		List<Person> personList = personRepository.findAll();
		for (Person person : personList) {
			if(person.getPassport().getPassportNo()==passportNo)
			{
				result.add(person);
			}
		}
		return result;
	}

}
