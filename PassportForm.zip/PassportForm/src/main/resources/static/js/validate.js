function validateform() {
	var passport = document.getElementById("passnumber").value;
	if (passport == "") {
		alert('Please enter a valid passport number.');
		return false;
	} else {
		return true;
	}	