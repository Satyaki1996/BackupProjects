function validateForm()
        {
            if(document.getElementById('fname').value.length==0)
            {
                alert("First name cant be blank");
                return false;
            }
            else if(document.getElementById('lname').value.length==0)
            {
                alert("Last name cant be blank");
                return false;
            }
            else if(document.getElementById('addrs').value.length==0)
            {
                alert("Address cant be blank");
                return false;
            }
            else if(document.getElementById('city').value.length==0)
            {
                alert("Required fields be blank");
                return false;
            }
            else if(document.getElementById('state').value.length==0)
            {
                alert("Required fields be blank");
                return false;
            }
            else if(document.getElementById('postc').value.length==0)
            {
                alert("Postal Code cant be blank");
                return false;
            }
            else if(document.getElementById('postc').value.length<6)
            {
                alert("Postal Code must be of 6 digits");
                return false;
            }
            else if(document.getElementById('cntry').value.length==0)
            {
                alert("Required fields be blank");
                return false;
            }
            else if(document.getElementById('postc').value.length==0)
            {
                alert("Phone number must be of 10 digits");
                return false;
            }
            else if(!(document.getElementById('postc').value.length==10))
            {
                alert("Phone number must be of 10 digits");
                return false;
            }
            else if(document.getElementById('fax').value.length==0)
            {
                alert("Required fields be blank");
                return false;
            }
            else if(!(document.getElementById('email').value.length==(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/)))
            {
                alert("Email is invalid");
                return false;
            }
            else
            {
                alert("Submitted successfully")
            }
            return true;
        }