function getDetails()
        {
            fetch('http://localhost:8080/retrievingMobiles',{
                method:'GET',
                headers: {
                'Content-Type':'application/json'
                }
            }).then((response) => {
                response.json().then((mobiles) => {
                    // console.log(response,finalParsedData);
                    console.log("Response is =>",response);
                    console.log("Parsed data is =>",mobiles);
                    const table = document.createElement('table');
                    mobiles.forEach((mobile)=> {

                        let row = document.createElement('tr');
                        let col1 = document.createElement('td');
                        col1.textContent=mobile.mobileId;
                        col1.setAttribute('style','border:solid 15px')
                        
                        let col2 = document.createElement('td');
                        col2.textContent=mobile.mobileBrand;
                        col2.setAttribute('style','border:solid 15px')

                        let col3 = document.createElement('td');
                        col3.textContent=mobile.price;
                        col3.setAttribute('style','border:solid 15px')

                        let col4 = document.createElement('td');
                        col4.textContent = mobile.ram;
                        col4.setAttribute('style','border:solid 15px')

                        row.appendChild(col1);
                        row.appendChild(col2);
                        row.appendChild(col3);
                        row.appendChild(col4);
                        table.appendChild(row);                        
                    });
                    document.body.appendChild(table);
                });
            })
        }