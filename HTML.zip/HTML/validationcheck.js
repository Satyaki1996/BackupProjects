function returnform()
{
    var firstname = document.getElementById('fname').value;
    if(firstname == "" || firstname.length < 6 || firstname.length > 14 || (!firstname.match(/^[a-zA-Z]+$/)))
    {
        alert("First name should be having characters between 6 and 14.");
        return false;
    }
    var lastname = document.getElementById('lname').value;
    if(lastname == "" || lastname.length < 6 || lastname.length > 14 || (!lastname.match(/^[a-zA-Z]+$/)))
    {
        alert("Last name should be having characters between 6 and 14.");
        return false;
    }  
    
    var letters = /^[0-9a-zA-z]+$/;
    var password = document.getElementById('pass').value;
    if(!(password.match(/[a-z]/g) && password.match(
        /[A-Z]/g) && password.match(
        /[0-9]/g) && password.match(
        /[^a-zA-Z\d]/g) && password.length >= 8))
        {
            alert("Password should contain special character numeric and capital letter");
            return false;
        }

    var a = document.getElementById('hobby1').checked;
    var b = document.getElementById('hobby2').checked;
    var c = document.getElementById('hobby3').checked;
    var d = document.getElementById('hobby4').checked;
    var e = document.getElementById('hobby5').checked;
    var f = document.getElementById('hobby6').checked;
        if(a == false && b == false && c == false && d == false && e == false && f == false)
        {
            alert("Please select atlist one hobby");
            return false;
        }

        var x = document.getElementById('gender').checked;
        if(x == false)
        {
            alert("Please select the gender")
            return false;
        }

        var GivenDate = document.getElementById('checkdate').value;
        var CurrentDate = new Date();
        GivenDate = new Date(GivenDate);

        if(GivenDate <= CurrentDate){
            alert('Given date cannot be less than the current date.');
            return false;
        }

        var area = document.getElementById('textfield').value;
        if(area == "" || area.length < 20)
        {
            alert("Enter proper address.");
            return false;
        }
        var term = document.getElementById('terms').checked;
        if(term == false)
        {
            alert("Please check the required details.");
            return false;
        }        
}