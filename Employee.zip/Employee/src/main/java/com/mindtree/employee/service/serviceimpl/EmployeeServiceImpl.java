package com.mindtree.employee.service.serviceimpl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Comparator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.employee.entity.Employee;
import com.mindtree.employee.repository.EmployeeRepository;
import com.mindtree.employee.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public void sendEmployeeDetails(Employee employee) {

		employeeRepository.save(employee);

	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employeeList = employeeRepository.findAll();
		// Comparator<Employee> employeeComparator =
		// (o1,o2)->o1.getEmpName().compareToIgnoreCase(o2.getEmpName());
		Comparator<Employee> salaryComparator = (o1, o2) -> (o1.getEmpSalary() - o2.getEmpSalary());
		employeeList.sort(salaryComparator);
		return employeeList;
	}

	@Override
	public void importToExcel() throws IOException {

		String[] columns = { "empId", "empName", "empSalary", "address" };
		List<Employee> employeeList = employeeRepository.findAll();
		// Create a Workbook
		Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

		// Create a Sheet
		Sheet sheet = workbook.createSheet("Employee");

		// Create a Row
		Row headerRow = sheet.createRow(0);

		// Create cells
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columns[i]);
			// cell.setCellStyle(headerCellStyle);
		}

		// Create Other rows and cells with employees data
		int rowNum = 1;
		for (Employee employee : employeeList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(employee.getEmpId());

			row.createCell(1).setCellValue(employee.getEmpName());

			row.createCell(2).setCellValue(employee.getAddress());

			row.createCell(3).setCellValue(employee.getEmpSalary());
		}

		// Resize all columns to fit the content size
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream("Employee_Excel_Sheet.xlsx");
		workbook.write(fileOut);
		fileOut.close();

		// Closing the workbook
		workbook.close();
	}

	@Override
	public void serializeData() {

		List<Employee> employees = employeeRepository.findAll();

		FileOutputStream file1 = null;
		ObjectOutputStream output = null;
		try {
			file1 = new FileOutputStream("employee.txt");
			output = new ObjectOutputStream(file1);
			output.writeObject(employees);
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			System.out.println("IO Exception incurred");
		} finally {
			try {
				file1.close();
				output.close();
			} catch (IOException e) {
				System.out.println("IO Exception incurred");

			}

		}

		FileInputStream file2 = null;
		ObjectInputStream output2 = null;

		try {
			file2 = new FileInputStream("employee.txt");
			output2 = new ObjectInputStream(file2);
			@SuppressWarnings("unchecked")
			List<Employee> employeesDeserialized = (List<Employee>) output2.readObject();
			employeesDeserialized.stream().forEach(employee -> {
				System.out.println(employee.getEmpId() + " " + employee.getEmpName() + " " + employee.getAddress() + " "
						+ employee.getEmpSalary());
			});
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			System.out.println("IO Exception incurred");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found.");
			e.printStackTrace();
		}

	}

}
