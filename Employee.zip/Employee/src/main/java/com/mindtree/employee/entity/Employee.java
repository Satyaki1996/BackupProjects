package com.mindtree.employee.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "emp_id")
	private int empId;

	@Column(name = "emp_name")
	private String empName;

	@Column(name = "emp_salary")
	private int empSalary;

	@Column(name = "emp_address")
	private String address;

	public Employee() {
		super();

	}

	public Employee(int empId, String empName, int empSalary, String address) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.address = address;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", address=" + address
				+ "]";
	}

//	@Override
//	public int compareTo(Employee emp) {
//		
//		int result = this.empName.compareToIgnoreCase(emp.empName);
//		if(result != 0) {
//			return result;
//		}
//		if(result == 0)
//		{
//			result = this.empSalary - emp.empSalary;
//		}		
//		return result;
//	}
	
	

}
