package com.mindtree.employee.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.employee.entity.Employee;
import com.mindtree.employee.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@RequestMapping("/")
	public String showForm() {
		return "index";
	}

	@PostMapping("/success")
	public String insertEmployee(@ModelAttribute("employee") Employee employee, Model model) {
		model.addAttribute("command", employee);
		employeeService.sendEmployeeDetails(employee);
		System.out.println(employee);
		return "success";
	}

	@GetMapping("/view")
	public String getEmployeeList(Model model) {
		List<Employee> employeeList = employeeService.getAllEmployees();
		System.out.println(employeeList);
		model.addAttribute("list", employeeList);
		return "view";

	}

	@GetMapping("/exportdatatoexcel")
	public String importToExcel() throws IOException {
		employeeService.importToExcel();
		return "index";
	}

	@GetMapping("/serialize")
	public String serializeData() {
		
		employeeService.serializeData();
		return "Serialization And Deserialization done";
	}
}
