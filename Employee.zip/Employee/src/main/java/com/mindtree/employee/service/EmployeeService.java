package com.mindtree.employee.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.employee.entity.Employee;

@Service
public interface EmployeeService {

	public void sendEmployeeDetails(Employee employee);

	public List<Employee> getAllEmployees();

	public void importToExcel() throws IOException;

	public void serializeData();

}
