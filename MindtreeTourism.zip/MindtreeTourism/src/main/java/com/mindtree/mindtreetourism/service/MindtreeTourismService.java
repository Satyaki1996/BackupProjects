package com.mindtree.mindtreetourism.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.mindtreetourism.entity.TravelAgent;

@Service
public interface MindtreeTourismService {

	public TravelAgent addAgentDetails(TravelAgent travelAgent);

	public List<TravelAgent> getAgentDetails();

	public void addCustomerDetails(TravelAgent travelAgent);

}
