package com.mindtree.mindtreetourism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindtreeTourismApplication {

	public static void main(String[] args) {
		SpringApplication.run(MindtreeTourismApplication.class, args);
	}

}
