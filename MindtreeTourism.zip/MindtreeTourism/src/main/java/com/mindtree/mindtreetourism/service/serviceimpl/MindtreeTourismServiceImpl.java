package com.mindtree.mindtreetourism.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mindtreetourism.entity.Customer;
import com.mindtree.mindtreetourism.entity.TravelAgent;
import com.mindtree.mindtreetourism.repository.CustomerRepository;
import com.mindtree.mindtreetourism.repository.TravelAgentRepository;
import com.mindtree.mindtreetourism.service.MindtreeTourismService;

@Service
public class MindtreeTourismServiceImpl implements MindtreeTourismService {
	
	@Autowired
	private TravelAgentRepository travelAgentRepository;
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public TravelAgent addAgentDetails(TravelAgent travelAgent) {
		
		return travelAgentRepository.save(travelAgent);
	}

	@Override
	public List<TravelAgent> getAgentDetails() {
		
		return travelAgentRepository.findAll();
	}

	@Override
	public void addCustomerDetails(TravelAgent travelAgent) {
		
		List<Customer> customers = new ArrayList<Customer>();
		for (Customer customer : travelAgent.getCustomers()) {
			customer.setTravelAgent(travelAgent);
			customer.setFare((customer.getDestination() - customer.getSource()) * 20);
			customers.add(customer);			
		}
		travelAgent.setCustomers(customers);
		travelAgentRepository.save(travelAgent);
		
	}

}
