package com.mindtree.mindtreetourism.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="travelagent_details")
public class TravelAgent {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int travelAgentId;
	private String travelAgentName;
	private String travelAgentAddress;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "travelAgent")
	private List<Customer> customers;

	public TravelAgent() {
		super();

	}

	public TravelAgent(int travelAgentId, String travelAgentName, String travelAgentAddress, List<Customer> customers) {
		super();
		this.travelAgentId = travelAgentId;
		this.travelAgentName = travelAgentName;
		this.travelAgentAddress = travelAgentAddress;
		this.customers = customers;
	}

	public int getTravelAgentId() {
		return travelAgentId;
	}

	public void setTravelAgentId(int travelAgentId) {
		this.travelAgentId = travelAgentId;
	}

	public String getTravelAgentName() {
		return travelAgentName;
	}

	public void setTravelAgentName(String travelAgentName) {
		this.travelAgentName = travelAgentName;
	}

	public String getTravelAgentAddress() {
		return travelAgentAddress;
	}

	public void setTravelAgentAddress(String travelAgentAddress) {
		this.travelAgentAddress = travelAgentAddress;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

}
