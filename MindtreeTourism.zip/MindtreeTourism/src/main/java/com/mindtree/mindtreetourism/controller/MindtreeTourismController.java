package com.mindtree.mindtreetourism.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.mindtreetourism.entity.TravelAgent;
import com.mindtree.mindtreetourism.service.MindtreeTourismService;

@Controller
public class MindtreeTourismController {

	@Autowired
	private MindtreeTourismService mindtreeTourismService;

	@RequestMapping("/")
	public String index1() {
		return "index";
	}

	@RequestMapping("/addagent")
	public String index2() {
		return "addagent";
	}
	
	@PostMapping("/addagentdetails")
	public String addAgentDetails(@ModelAttribute("travelAgent") TravelAgent travelAgent,Model model)
	{
		mindtreeTourismService.addAgentDetails(travelAgent);
		model.addAttribute("travelAgent", travelAgent);
		return "addagent";
	}
	
	@GetMapping("/getagents")
	public String getAgentDetails(Model model)
	{
		model.addAttribute("agents", mindtreeTourismService.getAgentDetails());
		return "addcustomer";
	}
	
	@RequestMapping("/addcustomer")
	public String index3() {
		return "addcustomer";
	}
	
	@PostMapping("/addcustomerdetails")
	public String customerDetails(@ModelAttribute("travelAgent") TravelAgent travelAgent,Model model)
	{
		mindtreeTourismService.addCustomerDetails(travelAgent);
		return "addcustomer";
	}
}
