package com.mindtree.mindtreetourism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MindtreeTourismApplicationTests {

	@Test
	void contextLoads() {
	}

}
