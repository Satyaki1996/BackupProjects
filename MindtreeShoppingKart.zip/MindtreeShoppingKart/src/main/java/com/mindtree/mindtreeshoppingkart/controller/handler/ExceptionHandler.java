package com.mindtree.mindtreeshoppingkart.controller.handler;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;

import com.mindtree.mindtreeshoppingkart.controller.MindtreeShoppingController;
import com.mindtree.mindtreeshoppingkart.exception.controllerexception.ControllerException;

@ControllerAdvice(assignableTypes = MindtreeShoppingController.class)
public class ExceptionHandler {
	
	@org.springframework.web.bind.annotation.ExceptionHandler
	public String controllerExceptionHandler(ControllerException c, Model model)
	{
		Map<String,Object> error = new HashMap<String, Object>();
		error.put("timestamp", new Date());
		error.put("HttpStatus", HttpStatus.BAD_REQUEST.value());
		error.put("message", c.getMessage());
		model.addAttribute("error", error);
		return "errorpage";
		
	}

}
