package com.mindtree.mindtreeshoppingkart.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Kart {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int kartId;
	private String kartName;
	private int kartBudget;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "kart")
	private List<Item> items;

	public Kart() {
		super();

	}

	public Kart(int kartId, String kartName, int kartBudget, List<Item> items) {
		super();
		this.kartId = kartId;
		this.kartName = kartName;
		this.kartBudget = kartBudget;
		this.items = items;
	}

	public int getKartId() {
		return kartId;
	}

	public void setKartId(int kartId) {
		this.kartId = kartId;
	}

	public String getKartName() {
		return kartName;
	}

	public void setKartName(String kartName) {
		this.kartName = kartName;
	}

	public int getKartBudget() {
		return kartBudget;
	}

	public void setKartBudget(int kartBudget) {
		this.kartBudget = kartBudget;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

}
