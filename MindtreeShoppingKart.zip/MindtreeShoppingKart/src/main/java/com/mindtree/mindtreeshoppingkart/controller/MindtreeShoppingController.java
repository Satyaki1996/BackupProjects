package com.mindtree.mindtreeshoppingkart.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.mindtreeshoppingkart.entity.Item;
import com.mindtree.mindtreeshoppingkart.entity.Kart;
import com.mindtree.mindtreeshoppingkart.exception.controllerexception.ControllerException;
import com.mindtree.mindtreeshoppingkart.exception.serviceexception.ServiceException;
import com.mindtree.mindtreeshoppingkart.service.MindtreeShoppingService;

@Controller
public class MindtreeShoppingController {
	
	@Autowired
	private MindtreeShoppingService mindtreeShoppingService;
	
	@RequestMapping("/index")
	public String index1()
	{
		return "index";
	}
	
	@RequestMapping("/additem")
	public String index2()
	{
		return "additem";
	}
	
	@PostMapping("/additemdetails")	
	public String addItemDetails(@ModelAttribute("items") Item items, Model model)
	{
		model.addAttribute("items", items);
		mindtreeShoppingService.addItemDetails(items);
		return "additem";
	}
	
	@RequestMapping("/addkart")
	public String getKarts(Model model)
	{
		List<Item> itemList = mindtreeShoppingService.getItems();
		model.addAttribute("itemList", itemList);
		return "addkart";
	}
	
	@PostMapping("/addkartdetails")
	public String addKartDetails(@ModelAttribute("kart") Kart kart, Model model)
	{
		mindtreeShoppingService.addKartDetails(kart);
		return "index";
	}
	
	@GetMapping("/viewkarts")
	public String index3()
	{
		return "viewkarts";
	}
	
	@GetMapping("/getdetailsbykartname")
	public String getDetailsByKartName(@RequestParam("kartName") String kartName, Model model) throws ControllerException
	{
		List<Kart> kartDetails = null;
		try {
			kartDetails = mindtreeShoppingService.getKartDetailsByKartName(kartName);
		} catch (ServiceException e) {
			throw new ControllerException(e.getMessage(),e );
		}
		model.addAttribute("kartDetails", kartDetails);
		return "viewkarts";
	}
	
	@GetMapping("/viewitems")
	public String index4()
	{
		return "viewitems";
	}
	
	@GetMapping("/getdetailsbyitemname")
	public String getDetailsByItemName(@RequestParam("itemName") String itemName, Model model) throws ControllerException
	{
		List<Item> itemDetails = null;
		try {
			itemDetails = mindtreeShoppingService.getKartDetailsByItemName(itemName);
		} catch (ServiceException e) {
			throw new ControllerException(e.getMessage(),e);
		}
		model.addAttribute("itemDetails", itemDetails);
		return "viewitems";
	}
	
	@PostMapping("/exportkartstoexcel")
	public String exportKartsToExcel() throws IOException
	{
		mindtreeShoppingService.exportKartsToExcel();
		return "index";
	}
	
	@PostMapping("/exportitemstoexcel")
	public String exportItemsToExcel() throws IOException
	{
		mindtreeShoppingService.exportItemsToExcel();
		return "index";
	}

}
