package com.mindtree.mindtreeshoppingkart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.mindtreeshoppingkart.entity.Item;
import com.mindtree.mindtreeshoppingkart.entity.Kart;

@Repository
public interface KartRepository extends JpaRepository<Kart, Item>{

}
