package com.mindtree.mindtreeshoppingkart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindtreeShoppingKartApplication {

	public static void main(String[] args) {
		SpringApplication.run(MindtreeShoppingKartApplication.class, args);
	}

}
