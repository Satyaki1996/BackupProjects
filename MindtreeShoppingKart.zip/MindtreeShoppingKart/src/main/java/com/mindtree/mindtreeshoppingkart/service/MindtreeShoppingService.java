package com.mindtree.mindtreeshoppingkart.service;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.mindtreeshoppingkart.entity.Item;
import com.mindtree.mindtreeshoppingkart.entity.Kart;
import com.mindtree.mindtreeshoppingkart.exception.serviceexception.ServiceException;

@Service
public interface MindtreeShoppingService {

	public Item addItemDetails(Item items);

	public List<Item> getItems();

	public void addKartDetails(Kart kart);

	public List<Kart> getKartDetailsByKartName(String kartName) throws ServiceException;

	public List<Item> getKartDetailsByItemName(String itemName) throws ServiceException;

	public void exportKartsToExcel() throws IOException;

	public void exportItemsToExcel() throws IOException;

	

}
