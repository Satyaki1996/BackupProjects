package com.mindtree.mindtreeshoppingkart.service.serviceimpl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mindtreeshoppingkart.entity.Item;
import com.mindtree.mindtreeshoppingkart.entity.Kart;
import com.mindtree.mindtreeshoppingkart.exception.serviceexception.NoSuchItemFoundException;
import com.mindtree.mindtreeshoppingkart.exception.serviceexception.NoSuchKartFoundException;
import com.mindtree.mindtreeshoppingkart.exception.serviceexception.ServiceException;
import com.mindtree.mindtreeshoppingkart.repository.ItemRepository;
import com.mindtree.mindtreeshoppingkart.repository.KartRepository;
import com.mindtree.mindtreeshoppingkart.service.MindtreeShoppingService;

@Service
public class MindtreeShoppingServiceImpl implements MindtreeShoppingService {

	@Autowired
	private KartRepository kartRepository;

	@Autowired
	private ItemRepository itemRepository;

	@Override
	public Item addItemDetails(Item items) {

		return itemRepository.save(items);
	}

	@Override
	public List<Item> getItems() {

		return itemRepository.findAll();
	}

	@Override
	public void addKartDetails(Kart kart) {
		int totalBudget = 0;
		List<Item> items = new ArrayList<Item>();
		for (Item item : kart.getItems()) {
			item.setKart(kart);
			items.add(item);
			totalBudget = totalBudget + (item.getItemQuantity() * item.getItemPrice());
		}
		kart.setKartBudget(totalBudget);
		kart.setItems(items);
		kartRepository.save(kart);
	}

	@Override
	public List<Kart> getKartDetailsByKartName(String kartName) throws ServiceException {

		List<Kart> kartList = new ArrayList<Kart>();
		List<Kart> karts = kartRepository.findAll();
		int count = 0;
		for (Kart kart : karts) {
			if (kart.getKartName().equalsIgnoreCase(kartName)) {
				kartList.add(kart);
				count++;
			}
		}
		if (count == 0) {
			try {
				throw new NoSuchKartFoundException("Sorry! No such cart named as "+kartName+" found.");
			} catch (NoSuchKartFoundException e) {
				throw new ServiceException(e.getMessage(), e);
			}
		}
		return kartList;
	}

	@Override
	public List<Item> getKartDetailsByItemName(String itemName) throws ServiceException {

		List<Item> itemList = new ArrayList<Item>();
		List<Item> items = itemRepository.findAll();
		int count = 0;
		for (Item item : items) {
			if (item.getItemName().equalsIgnoreCase(itemName)) {
				itemList.add(item);
				count++;
			}
		}

		if (count == 0) {
			try {
				throw new NoSuchItemFoundException("Sorry! No Such Item Found.");
			} catch (NoSuchItemFoundException e) {
				throw new ServiceException(e.getMessage(), e);
			}
		}
		return itemList;
	}

	@Override
	public void exportKartsToExcel() throws IOException {
		String[] columns = { "kartId", "kartName", "kartBudget" };
		List<Kart> kartList = kartRepository.findAll();
		// Create a Workbook
		Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

		// Create a Sheet
		Sheet sheet = workbook.createSheet("Kart");

		// Create a Row
		Row headerRow = sheet.createRow(0);

		// Create cells
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columns[i]);
			// cell.setCellStyle(headerCellStyle);
		}

		// Create Other rows and cells with employees data
		int rowNum = 1;
		for (Kart kart : kartList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(kart.getKartId());

			row.createCell(1).setCellValue(kart.getKartName());

			row.createCell(2).setCellValue(kart.getKartBudget());

		}

		// Resize all columns to fit the content size
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream("Kart_Excel_Sheet.xlsx");
		workbook.write(fileOut);
		fileOut.close();

		// Closing the workbook
		workbook.close();
	}

	@Override
	public void exportItemsToExcel() throws IOException {
		String[] columns = { "itemId", "itemName", "itemQuantity", "itemPrice" };
		List<Item> itemList = itemRepository.findAll();
		// Create a Workbook
		Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

		// Create a Sheet
		Sheet sheet = workbook.createSheet("Item");

		// Create a Row
		Row headerRow = sheet.createRow(0);

		// Create cells
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columns[i]);
			// cell.setCellStyle(headerCellStyle);
		}

		// Create Other rows and cells with employees data
		int rowNum = 1;
		for (Item item : itemList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(item.getItemId());

			row.createCell(1).setCellValue(item.getItemName());

			row.createCell(2).setCellValue(item.getItemQuantity());
			
			row.createCell(3).setCellValue(item.getItemPrice());

		}

		// Resize all columns to fit the content size
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream("Item_Excel_Sheet.xlsx");
		workbook.write(fileOut);
		fileOut.close();

		// Closing the workbook
		workbook.close();
		
	}
}
