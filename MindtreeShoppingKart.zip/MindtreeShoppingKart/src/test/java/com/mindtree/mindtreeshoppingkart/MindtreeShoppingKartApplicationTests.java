package com.mindtree.mindtreeshoppingkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MindtreeShoppingKartApplicationTests {

	@Test
	void contextLoads() {
	}

}
