package com.mindtree.hotelmanagement.service;

import org.springframework.stereotype.Service;

import com.mindtree.hotelmanagement.entity.User;

@Service
public interface HotelService {

	public void saveTheUser(User user);

	public Object getAllSelectRooms(String roomType);

	public Object getAllHobbies();
	
	public User getAllUser(int userId);

	public void updateTheUser(User user);

	public void deleteTheUser(int userId);

	

}
