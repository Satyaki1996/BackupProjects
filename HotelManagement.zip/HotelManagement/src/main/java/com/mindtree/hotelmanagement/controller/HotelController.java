package com.mindtree.hotelmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.hotelmanagement.entity.User;
import com.mindtree.hotelmanagement.service.HotelService;

@Controller
public class HotelController {
	
	@Autowired
	private HotelService hotelService;
	
	@RequestMapping("/")
	public String index1()
	{
		return "index";
	}
	
	@RequestMapping("/addcustomerdetails")
	public String addCutomerDetails(Model model)
	{
		model.addAttribute("HobbyList", hotelService.getAllHobbies());
		return "add";
	}
	
	@RequestMapping("/view")
	public String index2()
	{
		return "view";
	}
	
	@RequestMapping("/viewcustomerdetails")
	public String viewCustomerDetails(@RequestParam("RoomValue") String roomType,Model model)
	{
		model.addAttribute("roomList", hotelService.getAllSelectRooms(roomType));
		return "view";
	}
	
	@PostMapping("/index")
	public String index3(User user)
	{
		hotelService.saveTheUser(user);
		return "home";
	}
	
	@RequestMapping("/updateform/{userId}")
	public String updateForm(Model model,@PathVariable int userId)
	{
		model.addAttribute("user", hotelService.getAllUser(userId));
		model.addAttribute("HobbyList", hotelService.getAllHobbies());
		return "add";
	}
	
	@RequestMapping("/hometoedit")
	public String index4(User user)
	{
		hotelService.updateTheUser(user);
		return "home";
	}
	
	@RequestMapping("/deleteAForm/{userId}")
	public String deleteForm(Model model,@PathVariable int userId)
	{
		hotelService.deleteTheUser(userId);
		return "view";
	}
}
