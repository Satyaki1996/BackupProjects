package com.mindtree.hotelmanagement.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hotelmanagement.entity.Hobby;
import com.mindtree.hotelmanagement.entity.User;
import com.mindtree.hotelmanagement.repository.HobbyRepository;
import com.mindtree.hotelmanagement.repository.UserRepository;
import com.mindtree.hotelmanagement.service.HotelService;

@Service
public class HotelServiceImpl implements HotelService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private HobbyRepository hobbyRepository;

	@Override
	public void saveTheUser(User user) {
		
		List<User> userList = new ArrayList<User>();
		userList.add(user);
		for (Hobby hobby : user.getUserHobby()) {
			if(hobby.getUserList()==null)
			{
				hobby.setUserList(userList);
			}
			else
			{
				for (User user1 : userList) {
					hobby.getUserList().add(user1);
				}
			}
		}
		userRepository.saveAndFlush(user);
	}

	@Override
	public Object getAllSelectRooms(String roomType) {
		
		List<User> userRoomList = new ArrayList<User>();
		List<User> userList = userRepository.findAll();
		for (User user : userList) {
			if(user.getUserRoomType().equalsIgnoreCase(roomType))
			{
				userRoomList.add(user);
			}
		}
		return userRoomList;
	}

	@Override
	public Object getAllHobbies() {
		return hobbyRepository.findAll();
	}

	@Override
	public User getAllUser(int userId) {
		Optional<User> userop = userRepository.findById(userId);
		User user = userop.get();
		return user;
	}

	@Override
	public void updateTheUser(User user) {
		List<User> userList = userRepository.findAll();
		for (User user2 : userList) {
			if(user2.getUserMobile()==user.getUserMobile())
			{
				user2.setUserName(user.getUserName());
				user2.setUserCheckIn(user.getUserCheckIn());
				user2.setUserCheckOut(user.getUserCheckOut());
			    user2.setUserRoomType(user.getUserRoomType());
			    user2.setUserHobby(user.getUserHobby());
			    user2.setUserGender(user.getUserGender());
			    user2.setUserComments(user.getUserComments());
			    user2.setUserEmail(user.getUserEmail());
			}
		}
		userRepository.saveAndFlush(user);
		
	}

	@Override
	public void deleteTheUser(int userId) {
		userRepository.deleteById(userId);
	}

}
