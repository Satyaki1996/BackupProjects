package com.mindtree.hotelmanagement.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;
	private String userName;
	private long userMobile;
	private Date userCheckIn;
	private Date userCheckOut;
	private String userRoomType;
	private String userGender;
	private String userComments;
	private String userEmail;
	@ManyToMany(cascade = CascadeType.PERSIST,mappedBy = "userList")
	private List<Hobby> userHobby;

	public User(int userId, String userName, long userMobile, Date userCheckIn, Date userCheckOut, String userRoomType,
			String userGender, String userComments, String userEmail, List<Hobby> userHobby) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userMobile = userMobile;
		this.userCheckIn = userCheckIn;
		this.userCheckOut = userCheckOut;
		this.userRoomType = userRoomType;
		this.userGender = userGender;
		this.userComments = userComments;
		this.userEmail = userEmail;
		this.userHobby = userHobby;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(long userMobile) {
		this.userMobile = userMobile;
	}

	public Date getUserCheckIn() {
		return userCheckIn;
	}

	public void setUserCheckIn(Date userCheckIn) {
		this.userCheckIn = userCheckIn;
	}

	public Date getUserCheckOut() {
		return userCheckOut;
	}

	public void setUserCheckOut(Date userCheckOut) {
		this.userCheckOut = userCheckOut;
	}

	public String getUserRoomType() {
		return userRoomType;
	}

	public void setUserRoomType(String userRoomType) {
		this.userRoomType = userRoomType;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

	public String getUserComments() {
		return userComments;
	}

	public void setUserComments(String userComments) {
		this.userComments = userComments;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public List<Hobby> getUserHobby() {
		return userHobby;
	}

	public void setUserHobby(List<Hobby> userHobby) {
		this.userHobby = userHobby;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userMobile=" + userMobile + ", userCheckIn="
				+ userCheckIn + ", userCheckOut=" + userCheckOut + ", userRoomType=" + userRoomType + ", userGender="
				+ userGender + ", userComments=" + userComments + ", userEmail=" + userEmail + ", userHobby="
				+ userHobby + "]";
	}

}
