package com.mindtree.hotelmanagement.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Hobby {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int hobbyId;
	private String hobbyName;
	@ManyToMany(cascade = CascadeType.PERSIST)
	private List<User> userList;

	public Hobby(int hobbyId, String hobbyName, List<User> userList) {
		super();
		this.hobbyId = hobbyId;
		this.hobbyName = hobbyName;
		this.userList = userList;
	}

	public int getHobbyId() {
		return hobbyId;
	}

	public void setHobbyId(int hobbyId) {
		this.hobbyId = hobbyId;
	}

	public String getHobbyName() {
		return hobbyName;
	}

	public void setHobbyName(String hobbyName) {
		this.hobbyName = hobbyName;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	@Override
	public String toString() {
		return "Hobby [hobbyId=" + hobbyId + ", hobbyName=" + hobbyName + ", userList=" + userList + "]";
	}

}
