package com.mindtree.oathdemotest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthDemoTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
