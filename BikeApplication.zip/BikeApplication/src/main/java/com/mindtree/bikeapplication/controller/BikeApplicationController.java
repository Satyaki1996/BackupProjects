package com.mindtree.bikeapplication.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.bikeapplication.entity.Company;
import com.mindtree.bikeapplication.entity.Customer;
import com.mindtree.bikeapplication.entity.Vehiclemodel;
import com.mindtree.bikeapplication.service.BikeApplicationService;

@Controller
public class BikeApplicationController {

	@Autowired
	private BikeApplicationService bikeApplicationService;

	String name = "";

	@RequestMapping("/index")
	public String index1() {
		return "index";
	}

	@RequestMapping("/customerpage")
	public String index2() {
		return "customerpage";
	}

	@PostMapping("/insertcustomer")
	public String insertCustomer(@ModelAttribute("customer") Customer customer) {
		bikeApplicationService.insertCustomerToDb(customer);
		return "customerpage";
	}

	@RequestMapping("/loginpage")
	public String checkCustomer(@RequestParam("customerName") String customerName,
			@RequestParam("password") String password, Model model) {
		name = customerName;
		String adminAccess = bikeApplicationService.checkingCustomerDetails(customerName, password);
		if (adminAccess.equals("successfull")) {
			return "adminpage";
		} else {
			return "errorpage";
		}
	}

	@RequestMapping("/vehicle")
	public String index3(Model model) {
		List<Company> companies = bikeApplicationService.getAllCompaniesFromDatabase();
		model.addAttribute("companies", companies);
		return "vehicle";
	}

	@RequestMapping("/buyavehicle")
	public String buyAVehicle(@RequestParam("modelId") int modelId, @RequestParam("orderDate") Date orderDate,
			@RequestParam("confirmDate") Date confirmDate, @RequestParam("quantity") int quantity,
			@RequestParam("totalPrice") int totalPrice) {
		bikeApplicationService.buyAVehicle(modelId, name, orderDate, confirmDate, quantity, totalPrice);
		return "adminpage";
	}

	@RequestMapping("/customerdata")
	public String index4(Model model) {
		List<Customer> customers = bikeApplicationService.getAllCustomerDetails();
		model.addAttribute("customers", customers);
		return "customerdata";
	}

	@RequestMapping("/getcustomerdata")
	public String getCustomerData(@RequestParam("customerName") String customerName, Model model) {
		List<Customer> customerDatas = bikeApplicationService.getParticularCustomerData(customerName);
		model.addAttribute("customerDatas", customerDatas);
		return "customerdata";
	}

	@RequestMapping("/modeldata")
	public String index5(Model model) {
		List<Vehiclemodel> vehicleModels = bikeApplicationService.getAllModels();
		model.addAttribute("vehicleModels", vehicleModels);
		return "modeldata";
	}

	@GetMapping("/getmodeldata")
	public String getModelData(@RequestParam("modelName") String modelName, Model model) {
		List<Customer> customerDatas = bikeApplicationService.getAllCustomerDatas(modelName);
		model.addAttribute("customerDatas", customerDatas);
		return "modeldata";
	}

	@RequestMapping("/surveydata")
	public String index6(Model model) {
		List<Company> companies = bikeApplicationService.getAllCompaniesFromDatabase();
		model.addAttribute("companies", companies);
		return "surveydata";
	}

	@GetMapping("/getrevenue")
	public String getRevenueData(@RequestParam("companyName") String companyName, Model model) {
		model.addAttribute("revenue", bikeApplicationService.getRevenueData(companyName));
		model.addAttribute("modelrevenue", bikeApplicationService.getAllModelRevenue(companyName));
		return "surveydata";
	}

	@PostMapping("/exportcustomerdatatoexcel")
	public String exportCustomerDataToExcel() throws IOException {
		bikeApplicationService.exportCustomerDataToExcel();
		return "index";
	}
	
	@GetMapping("/serialize")
	public String serializeData() {
		
		bikeApplicationService.serializeData();
		return "Serialization And Deserialization done";
	}
	
	@RequestMapping("/aboutus")
	public String index7()
	{
		return "aboutus";
	}
	
	@RequestMapping("/animation")
	public String index8()
	{
		return "animation";
	}

}
