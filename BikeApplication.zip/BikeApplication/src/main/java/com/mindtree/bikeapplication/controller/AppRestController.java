package com.mindtree.bikeapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.bikeapplication.dto.VehiclemodelDto;
import com.mindtree.bikeapplication.service.BikeApplicationService;

@RestController
@RequestMapping("/rest")
public class AppRestController {

	@Autowired
	private BikeApplicationService bikeApplicationService;

	@RequestMapping("/loadmodelbycompany/{companyId}")
	public List<VehiclemodelDto> getModels(@PathVariable int companyId) {
		System.out.println(companyId);
		List<VehiclemodelDto> result = bikeApplicationService.getModelsFromDb(companyId);
		return result;
	}

	@RequestMapping("/pricebymodel/{modelId}")
	public int getAllPrices(@PathVariable int modelId) {
		int price = bikeApplicationService.getPriceOfModels(modelId);
		return price;
	}

}
