package com.mindtree.bikeapplication.dto;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomerDto {

	private int customerId;
	private String customerName;
	private String customerHobby;
	private String customerGender;
	private String customerEmail;
	private String customerPhoneNumber;
	private String password;
	private String confirmpassword;
	private Date orderDate;
	private Date confirmDate;
	private int quantity;
	private int totalPrice;
	private int noOfDays;
	@JsonIgnoreProperties("customers")
	private VehiclemodelDto vehiclemodel;

	public CustomerDto() {
		super();
	}

	public CustomerDto(int customerId, String customerName, String customerHobby, String customerGender,
			String customerEmail, String customerPhoneNumber, String password, String confirmpassword, Date orderDate,
			Date confirmDate, int quantity, int totalPrice, int noOfDays, VehiclemodelDto vehiclemodel) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerHobby = customerHobby;
		this.customerGender = customerGender;
		this.customerEmail = customerEmail;
		this.customerPhoneNumber = customerPhoneNumber;
		this.password = password;
		this.confirmpassword = confirmpassword;
		this.orderDate = orderDate;
		this.confirmDate = confirmDate;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
		this.noOfDays = noOfDays;
		this.vehiclemodel = vehiclemodel;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerHobby() {
		return customerHobby;
	}

	public void setCustomerHobby(String customerHobby) {
		this.customerHobby = customerHobby;
	}

	public String getCustomerGender() {
		return customerGender;
	}

	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Date getConfirmDate() {
		return confirmDate;
	}

	public void setConfirmDate(Date confirmDate) {
		this.confirmDate = confirmDate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public VehiclemodelDto getVehiclemodel() {
		return vehiclemodel;
	}

	public void setVehiclemodel(VehiclemodelDto vehiclemodel) {
		this.vehiclemodel = vehiclemodel;
	}

}
