package com.mindtree.bikeapplication.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class VehiclemodelDto {

	private int modelId;
	private String modelName;
	private int modelPrice;
	@JsonIgnoreProperties("vehiclemodel")
	private List<CustomerDto> customers;
	@JsonIgnoreProperties("vehiclemodels")
	private CompanyDto company;

	public VehiclemodelDto() {
		super();
	}

	public VehiclemodelDto(int modelId, String modelName, int modelPrice, List<CustomerDto> customers,
			CompanyDto company) {
		super();
		this.modelId = modelId;
		this.modelName = modelName;
		this.modelPrice = modelPrice;
		this.customers = customers;
		this.company = company;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public int getModelPrice() {
		return modelPrice;
	}

	public void setModelPrice(int modelPrice) {
		this.modelPrice = modelPrice;
	}

	public List<CustomerDto> getCustomers() {
		return customers;
	}

	public void setCustomers(List<CustomerDto> customers) {
		this.customers = customers;
	}

	public CompanyDto getCompany() {
		return company;
	}

	public void setCompany(CompanyDto company) {
		this.company = company;
	}

}
