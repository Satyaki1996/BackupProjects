package com.mindtree.bikeapplication.service.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bikeapplication.dto.VehiclemodelDto;
import com.mindtree.bikeapplication.entity.Company;
import com.mindtree.bikeapplication.entity.Customer;
import com.mindtree.bikeapplication.entity.Vehiclemodel;
import com.mindtree.bikeapplication.repository.CompanyRepository;
import com.mindtree.bikeapplication.repository.CustomerRepository;
import com.mindtree.bikeapplication.repository.VehicleModelRepository;
import com.mindtree.bikeapplication.service.BikeApplicationService;

@Service
public class BikeApplicationServiceImpl implements BikeApplicationService {

	@Autowired
	private CompanyRepository companyRepository;

	@Autowired
	private VehicleModelRepository vehicleModelRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer insertCustomerToDb(Customer customer) {

		return customerRepository.save(customer);
	}

	@Override
	public String checkingCustomerDetails(String customerName, String password) {

		String login = null;
		for (Customer customer : customerRepository.findAll()) {
			if (customerName.equals(customer.getCustomerName())) {
				if (password.equals(customer.getPassword())) {
					login = "successfull";
				}
			}
		}

		return login;
	}

	@Override
	public List<Company> getAllCompaniesFromDatabase() {

		return companyRepository.findAll();
	}

	@Override
	public List<VehiclemodelDto> getModelsFromDb(int companyId) {

		List<VehiclemodelDto> modelTypes = new ArrayList<VehiclemodelDto>();
		for (Company company : companyRepository.findAll()) {
			if (companyId == company.getCompanyId()) {
				for (Vehiclemodel vehiclemodel : company.getVehiclemodels()) {
					VehiclemodelDto vehiclemodelDto = new VehiclemodelDto();
					vehiclemodelDto.setModelId(vehiclemodel.getModelId());
					vehiclemodelDto.setModelName(vehiclemodel.getModelName());
					vehiclemodelDto.setModelPrice(vehiclemodel.getModelPrice());
					modelTypes.add(vehiclemodelDto);
				}
			}

		}

		return modelTypes;
	}

	@Override
	public int getPriceOfModels(int modelId) {

		int price = 0;
		for (Vehiclemodel vehiclemodel : vehicleModelRepository.findAll()) {
			if (modelId == vehiclemodel.getModelId()) {
				price = vehiclemodel.getModelPrice();
			}
		}
		return price;
	}

	@Override
	public Customer buyAVehicle(int modelId, String name, Date orderDate, Date confirmDate, int quantity,
			int totalPrice) {

		Vehiclemodel vehiclemodel = vehicleModelRepository.findById(modelId).get();
		Customer customer = customerRepository.findBycustomerName(name);

		customer.setOrderDate(orderDate);
		customer.setConfirmDate(confirmDate);
		customer.setQuantity(quantity);
		customer.setTotalPrice(totalPrice);

		int daysDiff = 0;
		long diff = confirmDate.getTime() - orderDate.getTime();
		long diffDays = diff / (24 * 60 * 60 * 1000);
		daysDiff = (int) diffDays;
		customer.setNoOfDays(daysDiff);

		customer.setVehiclemodel(vehiclemodel);
		vehiclemodel.getCustomers().add(customer);

		customerRepository.save(customer);
		vehicleModelRepository.save(vehiclemodel);
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerRepository.findAll();
	}

	@Override
	public List<Customer> getParticularCustomerData(String customerName) {

		List<Customer> customerList = new ArrayList<Customer>();

		for (Customer customer : customerRepository.findAll()) {
			if (customerName.equalsIgnoreCase(customer.getCustomerName())) {
				customerList.add(customer);
			}
		}

		return customerList;
	}

	@Override
	public List<Vehiclemodel> getAllModels() {
		return vehicleModelRepository.findAll();
	}

	@Override
	public List<Customer> getAllCustomerDatas(String modelName) {

		List<Customer> customerList = new ArrayList<Customer>();

		for (Vehiclemodel vehiclemodel : vehicleModelRepository.findAll()) {
			if (modelName.equalsIgnoreCase(vehiclemodel.getModelName())) {
				for (Customer customer : vehiclemodel.getCustomers()) {
					customerList.add(customer);
				}
			}
		}

		return customerList;
	}

	@Override
	public int getRevenueData(String companyName) {

		int totalRevenue = 0;

		for (Company company : companyRepository.findAll()) {
			if (companyName.equalsIgnoreCase(company.getCompanyName())) {
				for (Vehiclemodel vehiclemodel : company.getVehiclemodels()) {
					for (Customer customer : vehiclemodel.getCustomers()) {
						totalRevenue = totalRevenue + customer.getTotalPrice();
					}
				}
			}
		}

		return totalRevenue;
	}

	@Override
	public List<Vehiclemodel> getAllModelRevenue(String companyName) {
		int totalRevenue = 0;
		Vehiclemodel vehiclemodeltype = new Vehiclemodel();
		List<Vehiclemodel> vehiclemodels = new ArrayList<Vehiclemodel>();
		for (Company company : companyRepository.findAll()) {
			if (companyName.equalsIgnoreCase(company.getCompanyName())) {
				for (Vehiclemodel vehiclemodel : company.getVehiclemodels()) {
					vehiclemodeltype = vehiclemodel;
					for (Customer customer : vehiclemodel.getCustomers()) {
						if (vehiclemodeltype == customer.getVehiclemodel()) {
							totalRevenue = totalRevenue + customer.getTotalPrice();
						}
					}
					vehiclemodeltype.setModelPrice(totalRevenue);
					vehiclemodels.add(vehiclemodeltype);
					totalRevenue = 0;
				}
			}

		}
		return vehiclemodels;
	}

	@Override
	public String exportCustomerDataToExcel() throws IOException {

		String[] columns = { "customerId", "customerName", "customerHobby", "customerGender", "customerEmail",
				"customerPhoneNumber", "orderDate", "confirmDate", "quantity", "totalPrice", "noOfDays", "Model Name",
				"company Name" };
		List<Customer> customerList = customerRepository.findAll();
		// Create a Workbook
		Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

		// Create a Sheet
		Sheet sheet = workbook.createSheet("Customer");

		// Create a Row
		Row headerRow = sheet.createRow(0);

		// Create cells
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columns[i]);
			// cell.setCellStyle(headerCellStyle);
		}

		// Create Other rows and cells with customer data
		int rowNum = 1;
		for (Customer customer : customerList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(customer.getCustomerId());

			row.createCell(1).setCellValue(customer.getCustomerName());

			row.createCell(2).setCellValue(customer.getCustomerHobby());

			row.createCell(3).setCellValue(customer.getCustomerGender());

			row.createCell(4).setCellValue(customer.getCustomerEmail());

			row.createCell(5).setCellValue(customer.getCustomerPhoneNumber());

			row.createCell(6).setCellValue(customer.getOrderDate());

			row.createCell(7).setCellValue(customer.getConfirmDate());

			row.createCell(8).setCellValue(customer.getQuantity());

			row.createCell(9).setCellValue(customer.getTotalPrice());

			row.createCell(10).setCellValue(customer.getNoOfDays());

			row.createCell(11).setCellValue(customer.getVehiclemodel().getModelName());

			row.createCell(12).setCellValue(customer.getVehiclemodel().getCompany().getCompanyName());

		}

		// Resize all columns to fit the content size
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream("Customer_Excel_Sheet.xlsx");
		workbook.write(fileOut);
		fileOut.close();

		// Closing the workbook
		workbook.close();
		return "exported";
	}

	@Override
	public void serializeData() {
		List<Customer> customers = customerRepository.findAll();

		FileOutputStream file1 = null;
		ObjectOutputStream output = null;
		try {
			file1 = new FileOutputStream(new File("customer.txt"));
			output = new ObjectOutputStream(file1);
			output.writeObject(customers);
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			System.out.println("IO Exception incurred");
		} finally {
			try {
				file1.close();
				output.close();
			} catch (IOException e) {
				System.out.println("IO Exception incurred");

			}

		}

		FileInputStream file2 = null;
		ObjectInputStream output2 = null;

		try {
			file2 = new FileInputStream("customer.txt");
			output2 = new ObjectInputStream(file2);
			@SuppressWarnings("unchecked")
			List<Customer> customersDeserialized = (List<Customer>) output2.readObject();
			customersDeserialized.stream().forEach(customer -> {
				System.out.println(customer.getCustomerId() + " " + customer.getCustomerName() + " "
						+ customer.getCustomerHobby() + " " + customer.getCustomerGender() + " "
						+ customer.getCustomerEmail() + " " + customer.getCustomerPhoneNumber() + " "
						+ customer.getOrderDate() + " " + customer.getConfirmDate() + " " + customer.getQuantity() + " "
						+ customer.getTotalPrice() + " " + customer.getNoOfDays() + " "
						+ customer.getVehiclemodel().getModelName() + " "
						+ customer.getVehiclemodel().getCompany().getCompanyName() + " ");
			});
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			System.out.println("IO Exception incurred");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found.");
			e.printStackTrace();
		}

	}

}
