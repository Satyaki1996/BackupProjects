package com.mindtree.bikeapplication.service;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.bikeapplication.dto.VehiclemodelDto;
import com.mindtree.bikeapplication.entity.Company;
import com.mindtree.bikeapplication.entity.Customer;
import com.mindtree.bikeapplication.entity.Vehiclemodel;

/**
 * @author M1056069
 *
 */
@Service
public interface BikeApplicationService {

	/**
	 * @param customer
	 * @return
	 */
	public Customer insertCustomerToDb(Customer customer);

	/**
	 * @param customerName
	 * @param password
	 * @return
	 */
	public String checkingCustomerDetails(String customerName, String password);

	/**
	 * @return
	 */
	public List<Company> getAllCompaniesFromDatabase();

	/**
	 * @param companyId
	 * @return
	 */
	public List<VehiclemodelDto> getModelsFromDb(int companyId);

	/**
	 * @param modelId
	 * @return
	 */
	/**
	 * @param modelId
	 * @return
	 */
	public int getPriceOfModels(int modelId);

	/**
	 * @param modelId
	 * @param name
	 * @param orderDate
	 * @param confirmDate
	 * @param quantity
	 * @param totalPrice
	 * @return
	 */
	public Customer buyAVehicle(int modelId, String name, Date orderDate, Date confirmDate, int quantity,
			int totalPrice);

	/**
	 * @return
	 */
	public List<Customer> getAllCustomerDetails();

	/**
	 * @param customerName
	 * @return
	 */
	public List<Customer> getParticularCustomerData(String customerName);

	/**
	 * @return
	 */
	public List<Vehiclemodel> getAllModels();

	/**
	 * @param modelName
	 * @return
	 */
	public List<Customer> getAllCustomerDatas(String modelName);

	/**
	 * @param companyName
	 * @return
	 */
	public int getRevenueData(String companyName);

	/**
	 * @param companyName
	 * @return
	 */
	public List<Vehiclemodel> getAllModelRevenue(String companyName);

	/**
	 * @return
	 * @throws IOException
	 */
	public String exportCustomerDataToExcel() throws IOException;

	/**
	 * 
	 */
	public void serializeData();

}
