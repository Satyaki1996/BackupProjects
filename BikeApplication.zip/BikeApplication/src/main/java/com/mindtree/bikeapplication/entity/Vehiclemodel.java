package com.mindtree.bikeapplication.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Vehiclemodel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int modelId;
	private String modelName;
	private int modelPrice;

	@OneToMany(cascade = CascadeType.PERSIST, mappedBy = "vehiclemodel")
	private List<Customer> customers;

	@ManyToOne(fetch = FetchType.LAZY)
	private Company company;

	public Vehiclemodel() {
		super();
	}

	public Vehiclemodel(int modelId, String modelName, int modelPrice, List<Customer> customers, Company company) {
		super();
		this.modelId = modelId;
		this.modelName = modelName;
		this.modelPrice = modelPrice;
		this.customers = customers;
		this.company = company;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public int getModelPrice() {
		return modelPrice;
	}

	public void setModelPrice(int modelPrice) {
		this.modelPrice = modelPrice;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

}
