package com.mindtree.bikeapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.bikeapplication.entity.Vehiclemodel;

@Repository
public interface VehicleModelRepository extends JpaRepository<Vehiclemodel, Integer>{

}
