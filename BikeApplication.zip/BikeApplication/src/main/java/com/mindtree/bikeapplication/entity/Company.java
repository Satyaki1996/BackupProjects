package com.mindtree.bikeapplication.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int companyId;
	private String companyName;

	@OneToMany(cascade = CascadeType.PERSIST, mappedBy = "company")
	private List<Vehiclemodel> vehiclemodels;

	public Company() {
		super();
	}

	public Company(int companyId, String companyName, List<Vehiclemodel> vehiclemodels) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.vehiclemodels = vehiclemodels;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public List<Vehiclemodel> getVehiclemodels() {
		return vehiclemodels;
	}

	public void setVehiclemodels(List<Vehiclemodel> vehiclemodels) {
		this.vehiclemodels = vehiclemodels;
	}

}
