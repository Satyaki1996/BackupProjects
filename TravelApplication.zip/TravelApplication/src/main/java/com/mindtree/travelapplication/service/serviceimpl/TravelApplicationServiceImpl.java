package com.mindtree.travelapplication.service.serviceimpl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.travelapplication.dto.TravelDto;
import com.mindtree.travelapplication.entity.Customer;
import com.mindtree.travelapplication.entity.Travel;
import com.mindtree.travelapplication.exception.serviceexception.SameDateFoundException;
import com.mindtree.travelapplication.exception.serviceexception.ServiceException;
import com.mindtree.travelapplication.repository.CustomerRepository;
import com.mindtree.travelapplication.repository.TravelRepository;
import com.mindtree.travelapplication.service.TravelApplicationService;

@Service
public class TravelApplicationServiceImpl implements TravelApplicationService {

	@Autowired
	private TravelRepository travelRepository;

	@Autowired
	private CustomerRepository customerRepository;

	ModelMapper modelMapper = new ModelMapper();

	@Override
	public Customer insertCustomerToDb(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public List<Customer> getAllCustomersFromDb() {
		return customerRepository.findAll();
	}

	@Override
	public Travel insertTravelToDb(Travel travel, int customerId) throws ServiceException {

		Customer customer = customerRepository.getOne(customerId);
		List<Travel> travels = customer.getTravels();
		Date date = travel.getDateOfJourney();

		for (Travel travel2 : travels) {
			if (travel2.getDateOfJourney().equals(date)) {
					throw new SameDateFoundException("You have already booked an ticket on this date");
			} else {
				if (customer.getCustomerAge() > 30 && customer.getCustomerAge() <= 50) {
					travel.setTravelPrice((travel.getDistance() * 10) - (0.05 * travel.getDistance() * 10));
				} else if (customer.getCustomerAge() > 50) {
					travel.setTravelPrice((travel.getDistance() * 10) - (0.1 * travel.getDistance() * 10));
				} else {
					travel.setTravelPrice(travel.getDistance() * 10);
				}
				travel.setCustomer(customer);
			}

		}

		return travelRepository.save(travel);
	}

	@Override
	public List<TravelDto> getTravelsFromDb(int customerId) {

		List<TravelDto> travels = new ArrayList<TravelDto>();
		Customer customer = customerRepository.getOne(customerId);
		List<Travel> travelList = customer.getTravels();

		travels = travelList.stream().map(travel -> modelMapper.map(travel, TravelDto.class))
				.collect(Collectors.toList());
		return travels;
	}

	@Override
	public List<Travel> getBookingDetailsFromDb(int travelid, int customerid) {
		String source = travelRepository.findById(travelid).get().getSource();
		return customerRepository.findById(customerid).get().getTravels().stream()
				.filter(travel -> travel.getSource().equalsIgnoreCase(source)).collect(Collectors.toList());

	}

	@Override
	public Travel updateTravelData(int travelId) {

		Travel travelById = travelRepository.getOne(travelId);
		return travelById;
	}

	@Override
	public Travel updateTheTravelDetails(Travel travel, String source, String destination, double distance,
			int customerId) {

		Customer customer = customerRepository.getOne(customerId);
		travel.setSource(source);
		travel.setDestination(destination);
		travel.setDistance(distance);
		if (customer.getCustomerAge() > 30 && customer.getCustomerAge() <= 50) {
			travel.setTravelPrice((travel.getDistance() * 10) - (0.05 * travel.getDistance() * 10));
		} else if (customer.getCustomerAge() > 50) {
			travel.setTravelPrice((travel.getDistance() * 10) - (0.1 * travel.getDistance() * 10));
		} else {
			travel.setTravelPrice(travel.getDistance() * 10);
		}

		return travelRepository.save(travel);
	}

}
