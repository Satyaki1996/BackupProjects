package com.mindtree.travelapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.travelapplication.entity.Customer;
import com.mindtree.travelapplication.entity.Travel;
import com.mindtree.travelapplication.exception.TravelApplicationException;
import com.mindtree.travelapplication.service.TravelApplicationService;

@Controller
public class TravelApplicationController {

	@Autowired
	private TravelApplicationService travelApplicationService;

	Travel travel = new Travel();

	@RequestMapping("/")
	public String index1() {
		return "index";
	}

	@RequestMapping("/customerpage")
	public String index2() {
		return "customerpage";
	}

	@PostMapping("/customerregistration")
	public String insertCustomer(@ModelAttribute("customer") Customer customer) {
		travelApplicationService.insertCustomerToDb(customer);
		return "customerpage";
	}

	@RequestMapping("/travelpage")
	public String index3(Model model) {
		List<Customer> customers = travelApplicationService.getAllCustomersFromDb();
		model.addAttribute("customers", customers);
		return "travelpage";
	}

	@PostMapping("/travelregistration")
	public String insertTravel(@ModelAttribute("travel") Travel travel, @RequestParam("customerId") int customerId,
			Model model) throws TravelApplicationException {
		List<Customer> customers = travelApplicationService.getAllCustomersFromDb();
		model.addAttribute("customers", customers);
		travelApplicationService.insertTravelToDb(travel, customerId);
		return "travelpage";
	}

	@RequestMapping("/view")
	public String index4(Model model) {
		List<Customer> customers = travelApplicationService.getAllCustomersFromDb();
		model.addAttribute("customers", customers);
		return "view";
	}

	@GetMapping("/viewbookingdetails")
	public String getBookingDetails(@RequestParam("travelStatus") int source,
			@RequestParam("customerStatus") int customerid, Model model) {

		List<Travel> travelList = travelApplicationService.getBookingDetailsFromDb(source, customerid);
		model.addAttribute("travelList", travelList);
		List<Customer> customers = travelApplicationService.getAllCustomersFromDb();
		model.addAttribute("customers", customers);
		return "view";
	}

	@GetMapping("/update/{travelId}")
	public String updateTheTravelData(@PathVariable int travelId, Model model) {
		Travel travelObj = travelApplicationService.updateTravelData(travelId);
		travel = travelObj;
		model.addAttribute("travelObj", travelObj);
		return "update";
	}

	@RequestMapping("/updatethetraveldetails")
	public String updateTheTravelDetails(@RequestParam String source, @RequestParam String destination,
			@RequestParam double distance,Model model, @RequestParam("customerid") int customerId) {
		System.out.println("cus"+customerId);
		List<Customer> customers = travelApplicationService.getAllCustomersFromDb();
		model.addAttribute("customers", customers);
		travelApplicationService.updateTheTravelDetails(travel,source,destination,distance,customerId);
		return "view";

	}

}
