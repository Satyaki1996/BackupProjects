package com.mindtree.travelapplication.dto;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TravelDto {

	private int travelId;
	private String source;
	private String destination;
	private Date dateOfJourney;
	private double distance;
	private String foodPreference;
	private String document;
	private double travelPrice;
	@JsonIgnoreProperties("travels")
	private CustomerDto customer;

	public TravelDto() {
		super();
	}

	public TravelDto(int travelId, String source, String destination, Date dateOfJourney, double distance,
			String foodPreference, String document, double travelPrice, CustomerDto customer) {
		super();
		this.travelId = travelId;
		this.source = source;
		this.destination = destination;
		this.dateOfJourney = dateOfJourney;
		this.distance = distance;
		this.foodPreference = foodPreference;
		this.document = document;
		this.travelPrice = travelPrice;
		this.customer = customer;
	}

	public int getTravelId() {
		return travelId;
	}

	public void setTravelId(int travelId) {
		this.travelId = travelId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getDateOfJourney() {
		return dateOfJourney;
	}

	public void setDateOfJourney(Date dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public String getFoodPreference() {
		return foodPreference;
	}

	public void setFoodPreference(String foodPreference) {
		this.foodPreference = foodPreference;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public double getTravelPrice() {
		return travelPrice;
	}

	public void setTravelPrice(double travelPrice) {
		this.travelPrice = travelPrice;
	}

	public CustomerDto getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerDto customer) {
		this.customer = customer;
	}

}
