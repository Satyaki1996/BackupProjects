package com.mindtree.travelapplication.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.travelapplication.dto.TravelDto;
import com.mindtree.travelapplication.entity.Customer;
import com.mindtree.travelapplication.entity.Travel;
import com.mindtree.travelapplication.exception.serviceexception.ServiceException;

@Service
public interface TravelApplicationService {

	public Customer insertCustomerToDb(Customer customer);

	public List<Customer> getAllCustomersFromDb();

	public Travel insertTravelToDb(Travel travel, int customerId) throws ServiceException;

	public List<TravelDto> getTravelsFromDb(int customerId);

	public List<Travel> getBookingDetailsFromDb(int source, int customerid);

	public Travel updateTravelData(int travelId);

	public Travel updateTheTravelDetails(Travel travel, String source, String destination, double distance, int customerId);

}
