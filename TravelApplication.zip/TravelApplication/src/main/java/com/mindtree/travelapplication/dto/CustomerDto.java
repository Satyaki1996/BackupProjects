package com.mindtree.travelapplication.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomerDto {

	private int customerId;
	private String customerName;
	private int customerAge;
	@JsonIgnoreProperties("customer")
	private List<TravelDto> travels;

	public CustomerDto() {
		super();
	}

	public CustomerDto(int customerId, String customerName, int customerAge, List<TravelDto> travels) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAge = customerAge;
		this.travels = travels;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerAge() {
		return customerAge;
	}

	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}

	public List<TravelDto> getTravels() {
		return travels;
	}

	public void setTravels(List<TravelDto> travels) {
		this.travels = travels;
	}

}
