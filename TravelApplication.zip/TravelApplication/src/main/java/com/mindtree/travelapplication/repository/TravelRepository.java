package com.mindtree.travelapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.travelapplication.entity.Travel;

@Repository
public interface TravelRepository extends JpaRepository<Travel, Integer>{

	List<Travel> findBysource(String source);

}
