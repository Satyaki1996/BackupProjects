package com.mindtree.universityofmindtree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityOfMindtreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
