package com.mindtree.universityofmindtree.handler;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mindtree.universityofmindtree.controller.UniversityController;
import com.mindtree.universityofmindtree.exception.ControllerException;

@ControllerAdvice(assignableTypes = UniversityController.class)
public class UniversityControllerHandler {

	@ExceptionHandler
	public String controllerExceptionHandler(ControllerException c, Model model) {
		Map<String, Object> error = new LinkedHashMap<String, Object>();
		error.put("timestamp", new Date());
		error.put("HttpStatus", HttpStatus.BAD_REQUEST.value());
		error.put("message", c.getMessage());
		model.addAttribute("error", error);
		return "errorpage";
	}

}
