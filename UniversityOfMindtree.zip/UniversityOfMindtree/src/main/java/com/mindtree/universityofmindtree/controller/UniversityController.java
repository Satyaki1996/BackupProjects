package com.mindtree.universityofmindtree.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.universityofmindtree.entity.College;
import com.mindtree.universityofmindtree.entity.Lab;
import com.mindtree.universityofmindtree.entity.Student;
import com.mindtree.universityofmindtree.exception.ControllerException;
import com.mindtree.universityofmindtree.exception.ServiceException;
import com.mindtree.universityofmindtree.service.UniversityService;

@Controller
public class UniversityController {

	@Autowired
	private UniversityService universityService;

	@RequestMapping("/index")
	public String index1() {
		return "index";
	}

	@RequestMapping("/college")
	public String index2() {
		return "college";
	}

	@PostMapping("/addcollegedetails")
	public String addCollegeDetails(@ModelAttribute("college") College college, Model model) {
		universityService.addCollegeToDb(college);
		return "college";
	}

	@GetMapping("/lab")
	public String index3(Model model) {
		Set<College> colleges = universityService.getAllColleges();
		model.addAttribute("colleges", colleges);
		return "lab";
	}

	@PostMapping("/addlabdetails")
	public String addLabDetails(@ModelAttribute("lab") Lab lab, @RequestParam("collegeId") int collegeId, Model model) {
		universityService.addLabToDb(lab, collegeId);
		Set<College> colleges = universityService.getAllColleges();
		model.addAttribute("colleges", colleges);
		return "lab";
	}

	@RequestMapping("/student")
	public String index4() {
		return "student";
	}
	
	@PostMapping("/addstudentdetails")
	public String addStudentDetails(@ModelAttribute("student") Student student, Model model)
	{
		universityService.addStudentToDb(student);
		return "student";
	}
	
	@GetMapping("/assign")
	public String getStudentsAndLabs(Model model)
	{
		Set<Lab> labs = universityService.getAllLabs();
		model.addAttribute("labs", labs);
		Set<Student> students = universityService.getAllStudents();
		model.addAttribute("students", students);
		return "assign";
	}
	
	@PostMapping("/assignstudentsandlabs")
	public String assignStudentsAndLabs(@RequestParam("labId") int labId,@RequestParam("studentId") int studentId,Model model)
	{
		universityService.assignStudentToLabsInDb(labId,studentId);
		Set<Lab> labs = universityService.getAllLabs();
		model.addAttribute("labs", labs);
		Set<Student> students = universityService.getAllStudents();
		model.addAttribute("students", students);
		return "assign";
	}
	
	@RequestMapping("/searchbystudent")
	public String index5()
	{
		return "searchbystudent";
	}
	
	@GetMapping("/getlabsbystudentname")
	public String getLabsByStudentName(@RequestParam("studentName") String studentName,Model model) throws ControllerException
	{
		Set<Lab> labs;
		try {
			labs = universityService.getAllLabsByStudentName(studentName);
		} catch (ServiceException e) {
			throw new ControllerException(e.getMessage(),e);
		}
		model.addAttribute("labs", labs);
		return "searchbystudent";
	}

}
