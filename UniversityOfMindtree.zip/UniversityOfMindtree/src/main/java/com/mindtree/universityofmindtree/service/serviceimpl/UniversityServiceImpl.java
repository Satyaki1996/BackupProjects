package com.mindtree.universityofmindtree.service.serviceimpl;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.universityofmindtree.entity.College;
import com.mindtree.universityofmindtree.entity.Lab;
import com.mindtree.universityofmindtree.entity.Student;
import com.mindtree.universityofmindtree.exception.NoSuchStudentFoundException;
import com.mindtree.universityofmindtree.exception.ServiceException;
import com.mindtree.universityofmindtree.repository.CollegeRepository;
import com.mindtree.universityofmindtree.repository.LabRepository;
import com.mindtree.universityofmindtree.repository.StudentRepository;
import com.mindtree.universityofmindtree.service.UniversityService;

@Service
public class UniversityServiceImpl implements UniversityService {

	@Autowired
	private CollegeRepository collegeRepository;

	@Autowired
	private LabRepository labRepository;

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public College addCollegeToDb(College college) {

		return collegeRepository.save(college);
	}

	@Override
	public Set<College> getAllColleges() {

		Set<College> colleges = collegeRepository.findAll().stream().collect(Collectors.toSet());
		return colleges;
	}

	@Override
	public void addLabToDb(Lab lab, int collegeId) {

		College college = collegeRepository.getOne(collegeId);
		lab.setCollege(college);
		labRepository.save(lab);

	}

	@Override
	public Student addStudentToDb(Student student) {

		return studentRepository.save(student);
	}

	@Override
	public Set<Lab> getAllLabs() {

		Set<Lab> labs = labRepository.findAll().stream().collect(Collectors.toSet());
		return labs;
	}

	@Override
	public Set<Student> getAllStudents() {

		Set<Student> students = studentRepository.findAll().stream().collect(Collectors.toSet());
		return students;
	}

	@Override
	public void assignStudentToLabsInDb(int labId, int studentId) {
		Lab lab = labRepository.getOne(labId);
		Student student = studentRepository.getOne(studentId);
		Set<Lab> labs = new HashSet<Lab>();
		if (student.getLabs() == null) {
			labs.add(lab);
			student.setLabs(labs);
		} else {
			student.getLabs().add(lab);
		}
		studentRepository.save(student);
	}

	@Override
	public Set<Lab> getAllLabsByStudentName(String studentName) throws ServiceException {

		Optional<Student> students = studentRepository.findBystudentName(studentName);
		try {
			students.orElseThrow(() -> new NoSuchStudentFoundException("No such student found"));
		} catch (NoSuchStudentFoundException e) {
			throw new ServiceException(e.getMessage(), e);
		}
		return students.get().getLabs().stream().collect(Collectors.toSet());
	}

}
