package com.mindtree.universityofmindtree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityOfMindtreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversityOfMindtreeApplication.class, args);
	}

}
