package com.mindtree.universityofmindtree.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Lab {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int labId;
	private String labName;

	@ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	private College college;

	@ManyToMany(cascade = CascadeType.PERSIST, mappedBy = "labs")
	private Set<Student> students;

	public Lab() {
		super();

	}

	public Lab(int labId, String labName, College college, Set<Student> students) {
		super();
		this.labId = labId;
		this.labName = labName;
		this.college = college;
		this.students = students;
	}

	public int getLabId() {
		return labId;
	}

	public void setLabId(int labId) {
		this.labId = labId;
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}

	public College getCollege() {
		return college;
	}

	public void setCollege(College college) {
		this.college = college;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

}
