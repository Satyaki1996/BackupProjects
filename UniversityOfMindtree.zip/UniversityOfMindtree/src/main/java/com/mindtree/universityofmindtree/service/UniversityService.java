package com.mindtree.universityofmindtree.service;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.mindtree.universityofmindtree.entity.College;
import com.mindtree.universityofmindtree.entity.Lab;
import com.mindtree.universityofmindtree.entity.Student;
import com.mindtree.universityofmindtree.exception.ServiceException;

@Service
public interface UniversityService {

	/**
	 * @param college
	 * @return
	 */
	public College addCollegeToDb(College college);

	/**
	 * @return
	 */
	public Set<College> getAllColleges();

	/**
	 * @param lab
	 * @param collegeId
	 */
	public void addLabToDb(Lab lab, int collegeId);

	/**
	 * @param student
	 * @return
	 */
	public Student addStudentToDb(Student student);

	/**
	 * @return
	 */
	public Set<Lab> getAllLabs();

	/**
	 * @return
	 */
	public Set<Student> getAllStudents();

	/**
	 * @param labId
	 * @param studentId
	 */
	public void assignStudentToLabsInDb(int labId, int studentId);

	/**
	 * @param studentName
	 * @return
	 * @throws ServiceException
	 */
	public Set<Lab> getAllLabsByStudentName(String studentName) throws ServiceException;

}
