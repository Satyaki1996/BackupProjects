package com.mindtree.kalingatourism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KalingaTourismApplicationTests {

	@Test
	void contextLoads() {
	}

}
