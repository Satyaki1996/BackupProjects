package com.mindtree.kalingatourism.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.kalingatourism.entity.TravelPackage;
import com.mindtree.kalingatourism.repository.TravelPackageRepository;
import com.mindtree.kalingatourism.service.KalingaTourismService;

@Service
public class KalingaTourismServiceImpl implements KalingaTourismService {
	
	@Autowired
	private TravelPackageRepository travelPackageRepository;

	@Override
	public TravelPackage addPackageDetails(TravelPackage travelPackage) {
		
		return travelPackageRepository.save(travelPackage);
	}

	@Override
	public List<TravelPackage> getAllPackages() {
		List<TravelPackage> packageList = new ArrayList<TravelPackage>();
		List<TravelPackage> packages = travelPackageRepository.findAll();
		for (TravelPackage travelPackage : packages) {
			packageList.add(travelPackage);
		}
		return packageList;
	}

	@Override
	public List<TravelPackage> getAllPackagesById(int packageId) {
		
		List<TravelPackage> packageList = new ArrayList<TravelPackage>();
		List<TravelPackage> packages = travelPackageRepository.findAll();
		for (TravelPackage travelPackage : packages) {
			if(travelPackage.getPackageId()==packageId)
			{
				packageList.add(travelPackage);
			}
		}
		return packageList;
	}

	@Override
	public void updateTravelPackage(TravelPackage travelPackage) {
		
		travelPackageRepository.saveAndFlush(travelPackage);
		
	}

}
