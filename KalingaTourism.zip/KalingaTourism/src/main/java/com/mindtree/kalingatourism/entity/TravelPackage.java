package com.mindtree.kalingatourism.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class TravelPackage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int packageId;
	private String packageName;
	private int packageCost;
	private String packageDurationDay;
	private String packageDurationNight;
	private String packageFood;
	private String packageSeason;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "travelPackage")
	private List<Customer> customers;

	public TravelPackage() {
		super();

	}

	public TravelPackage(int packageId, String packageName, int packageCost, String packageDurationDay,
			String packageDurationNight, String packageFood, String packageSeason, List<Customer> customers) {
		super();
		this.packageId = packageId;
		this.packageName = packageName;
		this.packageCost = packageCost;
		this.packageDurationDay = packageDurationDay;
		this.packageDurationNight = packageDurationNight;
		this.packageFood = packageFood;
		this.packageSeason = packageSeason;
		this.customers = customers;
	}

	public int getPackageId() {
		return packageId;
	}

	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public int getPackageCost() {
		return packageCost;
	}

	public void setPackageCost(int packageCost) {
		this.packageCost = packageCost;
	}

	public String getPackageDurationDay() {
		return packageDurationDay;
	}

	public void setPackageDurationDay(String packageDurationDay) {
		this.packageDurationDay = packageDurationDay;
	}

	public String getPackageDurationNight() {
		return packageDurationNight;
	}

	public void setPackageDurationNight(String packageDurationNight) {
		this.packageDurationNight = packageDurationNight;
	}

	public String getPackageFood() {
		return packageFood;
	}

	public void setPackageFood(String packageFood) {
		this.packageFood = packageFood;
	}

	public String getPackageSeason() {
		return packageSeason;
	}

	public void setPackageSeason(String packageSeason) {
		this.packageSeason = packageSeason;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

}
