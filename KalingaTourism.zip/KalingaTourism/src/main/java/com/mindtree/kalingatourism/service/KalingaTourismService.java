package com.mindtree.kalingatourism.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.kalingatourism.entity.TravelPackage;

@Service
public interface KalingaTourismService {

	public TravelPackage addPackageDetails(TravelPackage travelPackage);

	public List<TravelPackage> getAllPackages();

	public List<TravelPackage> getAllPackagesById(int packageId);

	public void updateTravelPackage(TravelPackage travelPackage);

}
