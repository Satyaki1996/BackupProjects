package com.mindtree.kalingatourism.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.kalingatourism.entity.TravelPackage;
import com.mindtree.kalingatourism.service.KalingaTourismService;

@Controller
public class KalingaTourismController {
	
	@Autowired
	private KalingaTourismService kalingaTourismService;
	
	@RequestMapping("/index")
	public String index1()
	{
		return "index";
	}
	@RequestMapping("/addform")
	public String index2()
	{
		return "addform";
	}
	
	@PostMapping("/addformdetails")
	public String addFormDetails(@ModelAttribute("travelPackage") TravelPackage travelPackage, Model model)
	{
		model.addAttribute("travelPackage", travelPackage);
		kalingaTourismService.addPackageDetails(travelPackage);
		return "adform";
	}
	
	@GetMapping("/display")
	public String getAllPackages(Model model)
	{
		List<TravelPackage> packageList = kalingaTourismService.getAllPackages();
		model.addAttribute("packageList", packageList);
		return "display";
	}
	
	@GetMapping("/viewpackage/{packageId}")
	public String getPackageById(@RequestParam("packageId") int packageId, Model model)
	{
		List<TravelPackage> packages = kalingaTourismService.getAllPackagesById(packageId);
		model.addAttribute("packages", packages);
		return "update";
	}
	
	@PostMapping("/updatetable")
	public String updateTravelPackage(@RequestBody TravelPackage travelPackage)
	{
		kalingaTourismService.updateTravelPackage(travelPackage);
		return "updatename";
	}
	
	@RequestMapping("/customerbooking")
	public String customer()
	{
		return "searchhpage";
	}

}
