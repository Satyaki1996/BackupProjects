package com.mindtree.kalingatourism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KalingaTourismApplication {

	public static void main(String[] args) {
		SpringApplication.run(KalingaTourismApplication.class, args);
	}

}
