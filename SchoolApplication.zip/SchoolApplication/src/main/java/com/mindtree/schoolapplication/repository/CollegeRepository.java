package com.mindtree.schoolapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.schoolapplication.entity.College;

@Repository
public interface CollegeRepository extends JpaRepository<College, Integer>{

}
