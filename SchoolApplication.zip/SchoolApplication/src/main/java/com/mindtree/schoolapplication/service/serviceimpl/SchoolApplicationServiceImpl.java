package com.mindtree.schoolapplication.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.schoolapplication.entity.College;
import com.mindtree.schoolapplication.entity.Student;
import com.mindtree.schoolapplication.repository.CollegeRepository;
import com.mindtree.schoolapplication.repository.StudentRepository;
import com.mindtree.schoolapplication.service.SchoolApplicationService;

@Service
public class SchoolApplicationServiceImpl implements SchoolApplicationService {

	@Autowired
	private CollegeRepository collegeRepository;

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public College insertCollege(College college) {
		return collegeRepository.save(college);
	}

	@Override
	public List<College> getAllColleges() {
		return collegeRepository.findAll();
	}

	@Override
	public Student insertStudent(Student student, int collegeId) {

		List<College> colleges = collegeRepository.findAll();
		for (College college : colleges) {
			if (college.getCollegeId() == collegeId) {
				student.setCollege(college);
				if (student.getGender().equalsIgnoreCase("boy")) {
					college.setNoOfBoys(college.getNoOfBoys() + 1);

				}
				if (student.getGender().equalsIgnoreCase("girl")) {
					college.setNoOfGirls(college.getNoOfGirls() + 1);
				}
			}
			collegeRepository.save(college);
		}

		return studentRepository.save(student);
	}

	@Override
	public List<College> getCollegeDetails(int collegeId) {

		int boyCount = 0;
		int girlCount = 0;
		List<College> collegeList = new ArrayList<College>();
		List<College> colleges = collegeRepository.findAll();
		for (College college : colleges) {
			if (collegeId == college.getCollegeId()) {
				for (Student student : college.getStudents()) {
					if (student.getGender().equalsIgnoreCase("boy")) {
						boyCount++;
					}
					if (student.getGender().equalsIgnoreCase("girl")) {
						girlCount++;
					}
				}
			}
			college.setNoOfBoys(boyCount);
			college.setNoOfGirls(girlCount);
			collegeList.add(college);
			collegeRepository.save(college);
		}
		return collegeList;
	}

	@Override
	public List<Student> getAllStudents() {

		List<Student> students = studentRepository.findAll();
		Collections.sort(students);
		return students;
	}

	@Override
	public String deleteByStudent(int studentId) {

		Student student = studentRepository.findById(studentId).get();
		College college = student.getCollege();
		student.setCollege(null);
		studentRepository.deleteById(studentId);

		if (student.getGender().equalsIgnoreCase("boy")) {
			college.setNoOfBoys(college.getNoOfBoys() - 1);
			college.setCollegeStrength(college.getCollegeStrength() - 1);
		}
		if (student.getGender().equalsIgnoreCase("girl")) {
			college.setNoOfGirls(college.getNoOfGirls() - 1);
			college.setCollegeStrength(college.getCollegeStrength() - 1);
		}
		collegeRepository.saveAndFlush(college);
		return "Deleted successfully";
	}

}
