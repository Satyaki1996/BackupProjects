package com.mindtree.schoolapplication.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.schoolapplication.entity.College;
import com.mindtree.schoolapplication.entity.Student;

@Service
public interface SchoolApplicationService {

	public College insertCollege(College college);

	public List<College> getAllColleges();

	public Student insertStudent(Student student, int collegeId);

	public List<College> getCollegeDetails(int collegeId);

	public List<Student> getAllStudents();

	public String deleteByStudent(int studentId);

}
