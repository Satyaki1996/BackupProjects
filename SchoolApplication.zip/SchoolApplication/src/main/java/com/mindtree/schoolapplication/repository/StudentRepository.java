package com.mindtree.schoolapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.schoolapplication.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{

}
