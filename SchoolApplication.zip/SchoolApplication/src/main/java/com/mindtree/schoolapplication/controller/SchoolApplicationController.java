package com.mindtree.schoolapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.schoolapplication.entity.College;
import com.mindtree.schoolapplication.entity.Student;
import com.mindtree.schoolapplication.service.SchoolApplicationService;

@Controller
public class SchoolApplicationController {

	@Autowired
	private SchoolApplicationService schoolApplicationService;
	
	@RequestMapping("/")
	public String index()
	{
		return "index";
	}

	@RequestMapping("/college")
	public String index1() {
		return "college";
	}

	@PostMapping("/insertcollege")
	public String insertCollege(@ModelAttribute("college") College college) {
		schoolApplicationService.insertCollege(college);
		return "index";
	}

	@RequestMapping("/student")
	public String index2(Model model) {
		List<College> collegeList = schoolApplicationService.getAllColleges();
		model.addAttribute("collegeList", collegeList);
		return "student";
	}

	@PostMapping("/insertstudent")
	public String insertStudent(@ModelAttribute("student") Student student, @RequestParam("collegeId") int collegeId,
			Model model) {
		List<College> collegeList = schoolApplicationService.getAllColleges();
		model.addAttribute("collegeList", collegeList);
		schoolApplicationService.insertStudent(student,collegeId);
		return "student";
	}
	
	@RequestMapping("/viewcollege")
	public String index3(Model model)
	{
		List<College> collegeList = schoolApplicationService.getAllColleges();
		model.addAttribute("collegeList", collegeList);
		return "viewcollege";
	}
	
	@GetMapping("/getcollegedetails")
	public String getCollegeDetails(@RequestParam("collegeId") int collegeId,Model model)
	{
		List<College> collegeList = schoolApplicationService.getCollegeDetails(collegeId);
		model.addAttribute("collegeList", collegeList);
		return "viewcollege";
	}
	
	@GetMapping("/viewstudentdetails")
	public String getStudentDetails(Model model)
	{
		List<Student> studentList = schoolApplicationService.getAllStudents();
		model.addAttribute("studentList", studentList);
		return "viewstudent";
	}
	
	@RequestMapping("/delete/{studentId}")
	public String deleteStudent(@PathVariable int studentId)
	{
		schoolApplicationService.deleteByStudent(studentId);
		return "index";
	}
	
	

}
