package com.mindtree.schoolapplication.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class College {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int collegeId;
	private String collegeName;
	private int noOfBoys;
	private int noOfGirls;
	private int collegeStrength;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "college")
	private List<Student> students;

	public College() {
		super();
	}

	public College(int collegeId, String collegeName, int noOfBoys, int noOfGirls, int collegeStrength,
			List<Student> students) {
		super();
		this.collegeId = collegeId;
		this.collegeName = collegeName;
		this.noOfBoys = noOfBoys;
		this.noOfGirls = noOfGirls;
		this.collegeStrength = collegeStrength;
		this.students = students;
	}

	public int getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public int getNoOfBoys() {
		return noOfBoys;
	}

	public void setNoOfBoys(int noOfBoys) {
		this.noOfBoys = noOfBoys;
	}

	public int getNoOfGirls() {
		return noOfGirls;
	}

	public void setNoOfGirls(int noOfGirls) {
		this.noOfGirls = noOfGirls;
	}

	public int getCollegeStrength() {
		return collegeStrength;
	}

	public void setCollegeStrength(int collegeStrength) {
		this.collegeStrength = collegeStrength;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

}
