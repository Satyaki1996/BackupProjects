package com.mindtree.mindtreeschool.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class ClassEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int classEntityId;
	private String section;
	private String teacherName;
	private int noOfStudents;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "classEntity")
	private List<Student> students;

	public ClassEntity() {
		super();
	}

	public ClassEntity(int classEntityId, String section, String teacherName, int noOfStudents,
			List<Student> students) {
		super();
		this.classEntityId = classEntityId;
		this.section = section;
		this.teacherName = teacherName;
		this.noOfStudents = noOfStudents;
		this.students = students;
	}

	public int getClassEntityId() {
		return classEntityId;
	}

	public void setClassEntityId(int classEntityId) {
		this.classEntityId = classEntityId;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public int getNoOfStudents() {
		return noOfStudents;
	}

	public void setNoOfStudents(int noOfStudents) {
		this.noOfStudents = noOfStudents;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

}
