package com.mindtree.mindtreeschool.service.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mindtreeschool.entity.ClassEntity;
import com.mindtree.mindtreeschool.entity.Student;
import com.mindtree.mindtreeschool.exception.serviceexception.NumberOfStudentsExceedClassStrength;
import com.mindtree.mindtreeschool.exception.serviceexception.ServiceException;
import com.mindtree.mindtreeschool.repository.ClassEntityRepository;
import com.mindtree.mindtreeschool.repository.StudentRepository;
import com.mindtree.mindtreeschool.service.MindtreeSchoolService;

@Service
public class MindtreeSchoolServiceImpl implements MindtreeSchoolService {

	@Autowired
	private ClassEntityRepository classEntityRepository;

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public ClassEntity insertClassToDb(ClassEntity classEntity) {

		return classEntityRepository.save(classEntity);
	}

	@Override
	public List<ClassEntity> getAllSectionsOfClass() {

		List<ClassEntity> classes = classEntityRepository.findAll().stream().collect(Collectors.toList());
		return classes;
	}

	@Override
	public void insertStudentToDb(Student student, int classEntityId) throws ServiceException {

		ClassEntity classEntity = classEntityRepository.getOne(classEntityId);
		student.setStudentSection(classEntity.getSection());

		List<Student> students = studentRepository.findBystudentSection(classEntity.getSection());

		if (students.size() >= classEntity.getNoOfStudents()) {
			try {
				throw new NumberOfStudentsExceedClassStrength("Number of students exceed class strength");
			} catch (NumberOfStudentsExceedClassStrength e) {
				throw new ServiceException(e.getMessage(), e);
			}
		}
		student.setClassEntity(classEntity);
		studentRepository.save(student);

	}

	@Override
	public List<Student> getAllStudentsFromDb(int classEntityId) {
		
		ClassEntity classEntity = classEntityRepository.getOne(classEntityId);
		
		return classEntity.getStudents();
	}

	

}
