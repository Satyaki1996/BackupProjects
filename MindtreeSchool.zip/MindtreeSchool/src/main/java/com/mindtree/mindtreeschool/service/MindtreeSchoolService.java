package com.mindtree.mindtreeschool.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.mindtreeschool.entity.ClassEntity;
import com.mindtree.mindtreeschool.entity.Student;
import com.mindtree.mindtreeschool.exception.serviceexception.ServiceException;

@Service
public interface MindtreeSchoolService {

	public ClassEntity insertClassToDb(ClassEntity classEntity);

	public List<ClassEntity> getAllSectionsOfClass();

	public void insertStudentToDb(Student student, int classEntityId) throws ServiceException;

	public List<Student> getAllStudentsFromDb(int classEntityId);

}
