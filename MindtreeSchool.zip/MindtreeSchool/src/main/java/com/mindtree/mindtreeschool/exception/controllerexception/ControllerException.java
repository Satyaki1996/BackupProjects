package com.mindtree.mindtreeschool.exception.controllerexception;

import com.mindtree.mindtreeschool.exception.MindtreeSchoolException;

public class ControllerException extends MindtreeSchoolException {

	public ControllerException() {
		// TODO Auto-generated constructor stub
	}

	public ControllerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ControllerException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ControllerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ControllerException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
