package com.mindtree.mindtreeschool.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.mindtreeschool.entity.ClassEntity;
import com.mindtree.mindtreeschool.entity.Student;
import com.mindtree.mindtreeschool.exception.controllerexception.ControllerException;
import com.mindtree.mindtreeschool.exception.serviceexception.ServiceException;
import com.mindtree.mindtreeschool.service.MindtreeSchoolService;

@Controller
public class MindtreeSchoolController {

	@Autowired
	private MindtreeSchoolService mindtreeSchoolService;

	@RequestMapping("/index")
	public String index1() {
		return "index";
	}

	@RequestMapping("/class")
	public String index2() {
		return "class";
	}

	@PostMapping("/insertclass")
	public String insertClass(@ModelAttribute("classEntity") ClassEntity classEntity) {
		mindtreeSchoolService.insertClassToDb(classEntity);
		return "class";
	}

	@RequestMapping("/student")
	public String index3(Model model) {
		List<ClassEntity> classes = mindtreeSchoolService.getAllSectionsOfClass();
		model.addAttribute("classes", classes);
		return "student";
	}

	@PostMapping("/insertstudent")
	public String insertStudent(@ModelAttribute("student") Student student,
			@RequestParam("classEntityId") int classEntityId, Model model) throws ControllerException {
		try {
			mindtreeSchoolService.insertStudentToDb(student, classEntityId);
		} catch (ServiceException e) {
			throw new ControllerException(e.getMessage(), e);
		}
		List<ClassEntity> classes = mindtreeSchoolService.getAllSectionsOfClass();
		model.addAttribute("classes", classes);
		return "student";
	}

	@GetMapping("/display")
	public String index4(Model model) {
		List<ClassEntity> classes = mindtreeSchoolService.getAllSectionsOfClass();
		model.addAttribute("classes", classes);
		return "display";
	}

	@GetMapping("/displaystudentdetails")
	public String displayStudentDetails(@RequestParam("classEntityId") int classEntityId, Model model) {
		
		List<Student> students = mindtreeSchoolService.getAllStudentsFromDb(classEntityId);
		model.addAttribute("students", students);
		
		List<ClassEntity> classes = mindtreeSchoolService.getAllSectionsOfClass();
		model.addAttribute("classes", classes);
		
		return "display";
	}
}
