package com.mindtree.mindtreeschool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindtreeSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(MindtreeSchoolApplication.class, args);
	}

}
