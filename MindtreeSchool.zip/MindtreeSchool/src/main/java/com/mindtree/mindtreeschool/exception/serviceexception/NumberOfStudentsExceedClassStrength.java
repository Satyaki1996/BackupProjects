package com.mindtree.mindtreeschool.exception.serviceexception;

public class NumberOfStudentsExceedClassStrength extends ServiceException {

	public NumberOfStudentsExceedClassStrength() {
		// TODO Auto-generated constructor stub
	}

	public NumberOfStudentsExceedClassStrength(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NumberOfStudentsExceedClassStrength(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NumberOfStudentsExceedClassStrength(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public NumberOfStudentsExceedClassStrength(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
