package com.mindtree.airlinemanagement.service.serviceimpl;

import java.sql.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.airlinemanagement.entity.Flight;
import com.mindtree.airlinemanagement.entity.Passenger;
import com.mindtree.airlinemanagement.repository.FlightRepository;
import com.mindtree.airlinemanagement.repository.PassengerRepository;
import com.mindtree.airlinemanagement.service.AirlineService;

@Service
public class AirlineServiceImpl implements AirlineService {
	
	@Autowired
	private FlightRepository flightRepository;

	@Autowired
	private PassengerRepository passengerRepository;
	
	@Override
	public Flight addFlightsToDb(Flight flight) {
		return flightRepository.save(flight);
	}

	@Override
	public List<Flight> getAllFlightsFromDb() {
		
		List<Flight> flights = flightRepository.findAll().stream().collect(Collectors.toList());
		return flights;
	}

	@Override
	public Passenger addPassengersToDb(Passenger passenger, int flightId) {
		
		Flight flight = flightRepository.getOne(flightId);
		passenger.setFare((flight.getSource()-flight.getDestination()) * 50);
		passenger.setFlight(flight);
		return passengerRepository.save(passenger);
	}

	@Override
	public List<Passenger> getAllDetailsByFlight(int flightId) {
		
		List<Passenger> passengerList = flightRepository.findById(flightId).get().getPasengers();
		return passengerList;
	}

	@Override
	public Passenger updatePassengerDateOfJourney(Passenger pass, Date dateOfLeaving) {
		
		pass.setDateOfLeaving(dateOfLeaving);
		return passengerRepository.save(pass);
	}

	@Override
	public Passenger updatePassengerData(int passengerId) {
		Passenger passenger = passengerRepository.findById(passengerId).get();
		return passenger;
	}

	

}
