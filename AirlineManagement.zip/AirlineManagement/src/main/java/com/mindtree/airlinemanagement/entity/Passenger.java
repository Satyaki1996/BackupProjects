package com.mindtree.airlinemanagement.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Passenger {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int passengerId;
	private String passengerName;
	private Date dateOfLeaving;
	private String hobby;
	private String food;
	private int fare;

	@ManyToOne(fetch = FetchType.LAZY)
	private Flight flight;

	public Passenger() {
		super();
	}

	public Passenger(int passengerId, String passengerName, Date dateOfLeaving, String hobby, String food, int fare,
			Flight flight) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.dateOfLeaving = dateOfLeaving;
		this.hobby = hobby;
		this.food = food;
		this.fare = fare;
		this.flight = flight;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public Date getDateOfLeaving() {
		return dateOfLeaving;
	}

	public void setDateOfLeaving(Date dateOfLeaving) {
		this.dateOfLeaving = dateOfLeaving;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

}
