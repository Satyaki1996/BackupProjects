package com.mindtree.airlinemanagement.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int flightId;
	private int flightNumber;
	private String flightName;
	private int source;
	private int destination;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "flight")
	private List<Passenger> pasengers;

	public Flight() {
		super();
	}

	public Flight(int flightId, int flightNumber, String flightName, int source, int destination,
			List<Passenger> pasengers) {
		super();
		this.flightId = flightId;
		this.flightNumber = flightNumber;
		this.flightName = flightName;
		this.source = source;
		this.destination = destination;
		this.pasengers = pasengers;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public int getSource() {
		return source;
	}

	public void setSource(int source) {
		this.source = source;
	}

	public int getDestination() {
		return destination;
	}

	public void setDestination(int destination) {
		this.destination = destination;
	}

	public List<Passenger> getPasengers() {
		return pasengers;
	}

	public void setPasengers(List<Passenger> pasengers) {
		this.pasengers = pasengers;
	}

}
