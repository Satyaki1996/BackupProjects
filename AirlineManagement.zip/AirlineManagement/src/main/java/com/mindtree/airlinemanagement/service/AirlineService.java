package com.mindtree.airlinemanagement.service;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.airlinemanagement.entity.Flight;
import com.mindtree.airlinemanagement.entity.Passenger;

@Service
public interface AirlineService {

	public Flight addFlightsToDb(Flight flight);

	public List<Flight> getAllFlightsFromDb();

	public Passenger addPassengersToDb(Passenger passenger, int flightId);

	public List<Passenger> getAllDetailsByFlight(int flightId);

	public Passenger updatePassengerDateOfJourney(Passenger pass, Date dateOfLeaving);

	public Passenger updatePassengerData(int passengerId);

}
