package com.mindtree.airlinemanagement.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.airlinemanagement.entity.Flight;
import com.mindtree.airlinemanagement.entity.Passenger;
import com.mindtree.airlinemanagement.service.AirlineService;

@Controller
public class AirlineController {

	@Autowired
	private AirlineService airlineService;

	Passenger pass = new Passenger();

	@RequestMapping("/index")
	public String index1() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		System.out.println(auth.getPrincipal());

		return "index";
	}

	@RequestMapping("/flight")
	public String index2() {
		return "flight";
	}

	@PostMapping("/addflights")
	public String addFlights(@ModelAttribute("flight") Flight flight) {
		airlineService.addFlightsToDb(flight);
		return "flight";
	}

	@GetMapping("/passenger")
	public String index3(Model model) {
		List<Flight> flights = airlineService.getAllFlightsFromDb();
		model.addAttribute("flights", flights);
		return "passenger";
	}

	@PostMapping("/addpassengers")
	public String addPassengers(@ModelAttribute("passenger") Passenger passenger,
			@RequestParam("flightId") int flightId, Model model) {
		airlineService.addPassengersToDb(passenger, flightId);
		List<Flight> flights = airlineService.getAllFlightsFromDb();
		model.addAttribute("flights", flights);
		return "faredetails";
	}

	@RequestMapping("/viewbyflight")
	public String index4(Model model) {
		List<Flight> flights = airlineService.getAllFlightsFromDb();
		model.addAttribute("flights", flights);
		return "viewbyflight";
	}

	@RequestMapping("/getalldetailsbyflight")
	public String getAllDetailsByFlight(@RequestParam("flightId") int flightId, Model model) {
		List<Flight> flights = airlineService.getAllFlightsFromDb();
		model.addAttribute("flights", flights);
		List<Passenger> passengers = airlineService.getAllDetailsByFlight(flightId);
		model.addAttribute("passengers", passengers);
		return "viewbyflight";
	}

	@GetMapping("/update/{passengerId}")
	public String updateThePassengerDate(@PathVariable int passengerId, Model model) {
		Passenger passenger = airlineService.updatePassengerData(passengerId);
		model.addAttribute("passenger", passenger);
		pass = passenger;
		return "update";
	}

	@RequestMapping("/updatedata")
	public String updatePassengerDateOfJourney(@RequestParam("dateOfLeaving") Date dateOfLeaving, Model model) {
		List<Flight> flights = airlineService.getAllFlightsFromDb();
		model.addAttribute("flights", flights);
		airlineService.updatePassengerDateOfJourney(pass, dateOfLeaving);
		return "viewbyflight";
	}

}
