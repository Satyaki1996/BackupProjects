package com.mindtree.airlinemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
