package com.mindtree.bankapplication.service.serviceimpl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bankapplication.entity.Customer;
import com.mindtree.bankapplication.entity.DebitCard;
import com.mindtree.bankapplication.repository.CustomerRepository;
import com.mindtree.bankapplication.repository.DebitCardRepository;
import com.mindtree.bankapplication.service.BankApplicationService;

@Service
public class BankApplicationServiceImpl implements BankApplicationService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private DebitCardRepository debitCardRepository;

	@Override
	public Customer resgisterCustomerToDb(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public List<Customer> getAllCustomersFromDb() {

		return customerRepository.findAll().stream().collect(Collectors.toList());
	}

	@Override
	public DebitCard addDebitCardToDb(DebitCard debitCard, int customerId) {

		Customer customer = customerRepository.getOne(customerId);
		debitCard.setCustomer(customer);
		return debitCardRepository.save(debitCard);
	}

	@Override
	public List<Customer> getAllCustomerCardDetailsFromDb() {

		List<Customer> customerList = new ArrayList<Customer>();
		List<Customer> customers = customerRepository.findAll();

		customerList = customers.stream().collect(Collectors.toList());
		Collections.sort(customerList);

		for (Customer customer : customerList) {
			Collections.sort(customer.getDebitCards());
		}
		return customerList;
	}

	@Override
	public DebitCard getData(int debitCardId) {

		DebitCard debitCard = debitCardRepository.findById(debitCardId).get();
		return debitCard;
	}

	@Override
	public String updateCardDetails(Date dateOfExpiry, DebitCard debit) {

		debit.setDateOfExpiry(dateOfExpiry);
		debitCardRepository.save(debit);
		return "updated";
	}

}
