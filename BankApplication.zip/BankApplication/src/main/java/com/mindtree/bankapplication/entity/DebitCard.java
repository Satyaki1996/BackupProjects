package com.mindtree.bankapplication.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class DebitCard implements Comparable<DebitCard>{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int debitCardId;
	private long debitCardNumber;
	private Date dateOfExpiry;
	private int debitCardAmount;
	private String debitCardType;

	@ManyToOne(fetch = FetchType.LAZY)
	private Customer customer;

	public DebitCard() {
		super();
	}

	public DebitCard(int debitCardId, long debitCardNumber, Date dateOfExpiry, int debitCardAmount,
			String debitCardType, Customer customer) {
		super();
		this.debitCardId = debitCardId;
		this.debitCardNumber = debitCardNumber;
		this.dateOfExpiry = dateOfExpiry;
		this.debitCardAmount = debitCardAmount;
		this.debitCardType = debitCardType;
		this.customer = customer;
	}

	public int getDebitCardId() {
		return debitCardId;
	}

	public void setDebitCardId(int debitCardId) {
		this.debitCardId = debitCardId;
	}

	public long getDebitCardNumber() {
		return debitCardNumber;
	}

	public void setDebitCardNumber(long debitCardNumber) {
		this.debitCardNumber = debitCardNumber;
	}

	public Date getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(Date dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

	public int getDebitCardAmount() {
		return debitCardAmount;
	}

	public void setDebitCardAmount(int debitCardAmount) {
		this.debitCardAmount = debitCardAmount;
	}

	public String getDebitCardType() {
		return debitCardType;
	}

	public void setDebitCardType(String debitCardType) {
		this.debitCardType = debitCardType;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public int compareTo(DebitCard card) {
		return card.debitCardAmount - this.getDebitCardAmount();
	}

}
