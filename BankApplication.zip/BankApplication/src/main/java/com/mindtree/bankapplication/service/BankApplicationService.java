package com.mindtree.bankapplication.service;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.bankapplication.entity.Customer;
import com.mindtree.bankapplication.entity.DebitCard;

@Service
public interface BankApplicationService {

	/**
	 * @param customer
	 * @return
	 */
	public Customer resgisterCustomerToDb(Customer customer);

	/**
	 * @return
	 */
	List<Customer> getAllCustomersFromDb();

	/**
	 * @param debitCard
	 * @param customerId 
	 * @return
	 */
	public DebitCard addDebitCardToDb(DebitCard debitCard, int customerId);

	/**
	 * @return
	 */
	List<Customer> getAllCustomerCardDetailsFromDb();

	/**
	 * @param debitCardId
	 * @return
	 */
	public DebitCard getData(int debitCardId);
	
	/**
	 * @param dateOfExpiry
	 * @param debit
	 * @return
	 */
	public String updateCardDetails(Date dateOfExpiry, DebitCard debit);

}
