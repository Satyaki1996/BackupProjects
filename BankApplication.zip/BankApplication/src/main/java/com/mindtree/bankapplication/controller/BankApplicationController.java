package com.mindtree.bankapplication.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.bankapplication.entity.Customer;
import com.mindtree.bankapplication.entity.DebitCard;
import com.mindtree.bankapplication.service.BankApplicationService;

@Controller
public class BankApplicationController {

	@Autowired
	private BankApplicationService bankApplicationService;
	
	DebitCard debit = new DebitCard();

	@RequestMapping("/")
	public String index1() {
		return "index";
	}

	@RequestMapping("/register")
	public String index2() {
		return "register";
	}

	@PostMapping("/registercustomer")
	public String registerCustomer(@ModelAttribute("customer") Customer customer) {
		bankApplicationService.resgisterCustomerToDb(customer);
		return "register";
	}

	@GetMapping("/debitcard")
	public String index3(Model model) {
		List<Customer> customers = bankApplicationService.getAllCustomersFromDb();
		model.addAttribute("customers", customers);
		return "debitcard";
	}

	@PostMapping("/adddebitcard")
	public String addDebitCard(@ModelAttribute("debitCard") DebitCard debitCard, @RequestParam("customerId") int customerId,
	Model model) {
		bankApplicationService.addDebitCardToDb(debitCard,customerId);
		List<Customer> customers = bankApplicationService.getAllCustomersFromDb();
		model.addAttribute("customers", customers);
		return "index";
	}

	@RequestMapping("/view")
	public String index4() {
		return "view";
	}

	@GetMapping("/getcustomerdebitcarddetails")
	public String getDebitCardDetails(Model model) {
		List<Customer> customerCardDetails = bankApplicationService.getAllCustomerCardDetailsFromDb();
		model.addAttribute("customerCardDetails", customerCardDetails);
		return "view";
	}
	
	@RequestMapping("/update/{debitCardId}")
	public String index5(@PathVariable int debitCardId, Model model)
	{
		DebitCard debitCard = bankApplicationService.getData(debitCardId);
		model.addAttribute("debitCard", debitCard);
		debit = debitCard;
		return "update";
	}
	
	@PostMapping("/updatedata")
	public String updateByDate(@RequestParam("dateOfExpiry") Date dateOfExpiry)
	{
		bankApplicationService.updateCardDetails(dateOfExpiry,debit);
		return "view";
	}

}
